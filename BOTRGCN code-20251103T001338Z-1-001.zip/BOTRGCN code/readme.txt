BOTRGCN (Twibot-style) — Quick Start
=========================================

This repo trains a TwiBot-style BotRGCN on your Twitter-like CSV and optional edges.
It follows the original TwiBot22 flow but adapts to your dataset columns.

0) Requirements
---------------
- Python 3.9–3.12
- Install:
  pip install torch transformers pandas numpy scikit-learn tqdm

Files used here (must be in the repo):
- preprocess.py, preprocess_1.py, preprocess_2.py
- Dataset_Original.py, Dataset.py, model.py, train.py, test_data.py
- dataset_tool.py, utils.py  (must exist; contains relation vocab & helpers)

Mac users: MPS will be used automatically if available; otherwise CUDA or CPU.

1) Filter a large edge file. 
--------------------------------------
Trim a global edges file down to users in your CSV:
  python filter_edge_big_to_dataset.py     --csv /path/to/Benchmark_data_1m.csv     --edges /path/to/global_edges.csv     --out  /path/to/edge_from_big_1m_new.csv

Use the --out file as EDGES_PATH in step 2. 

(Note: Make sure to create edge.csv for both training and prediction)

2) Point the data paths
-----------------------
Open preprocess_1.py and set:
  CSV_PATH   = "/absolute/path/to/Benchmark_data_1m.csv"
  EDGES_PATH = "/absolute/path/to/edge_from_big_1m_new.csv"

CSV required columns (case-insensitive):
  user_id, label (bot/human), split (train/val/test),
  user_profile, tweet_text

Optional but supported columns (improves features):
  user_followers_count, user_following_count, user_tweets_count, user_listed_count,
  user_username, user_created_at, user_verified, user_place, user_pinned_tweet_id

Edges CSV (optional):
  source_id, target_id, relation in {mentioned, replied_to, co_mention, co_reply, same_conversation}

3) Preprocess (splits/graph/features)
-------------------------------------
Runs 2 steps internally (Step 1: ids/splits/edges, Step 2: embeddings & properties):
  python preprocess.py

Outputs saved to ./processed_data/:
  train_idx.pt, val_idx.pt, test_idx.pt, label.pt
  edge_index.pt, edge_type.pt
  des_tensor.pt, tweets_tensor.pt
  num_properties_tensor.pt, cat_properties_tensor.pt

First run downloads HF models (distilroberta-base, roberta-base), so it may take time.

4) Train
--------
  python train.py

This will load from ./processed_data/, train BotRGCN with warmup & early stopping, then save:
  best_bot_detection_model.pth
  trained_bot_detection_model_optimized.pth
  training_log.json

(OPTIONAL) Tell the trainer the real-world human prior (if humans ≫ bots, e.g., 95/5):
  export TARGET_HUMAN_PRIOR=0.95
  python train.py

If not set, the trainer uses class weights from the training split frequencies.

5) Predict on a new CSV
-----------------------
  python test_data.py     --csv /absolute/path/to/new_data.csv --edges /absolute/path/to/new_edges.csv \ 
    --model trained_bot_detection_model_optimized.pth  --output predictions.csv

Outputs:
  predictions.csv (per-user probabilities, labels, confidence)
  If labels exist in the CSV, metrics & ROC/PR curves are saved alongside the output.



Common issues
-------------
- Shape mismatch after changing CSV? Delete ./processed_data/ and re-run:
    rm -rf ./processed_data
    python preprocess.py
- Slow text embeddings: it’s normal on first run due to model downloads and encoding.

Cheat sheet
-----------
Preprocess:  python preprocess.py
Train:       python train.py
Predict:     python test_data.py --csv new.csv --edges edge.csv --model trained_bot_detection_model_optimized.pth --output out.csv

