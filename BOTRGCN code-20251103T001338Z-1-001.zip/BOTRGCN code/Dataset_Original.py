# Dataset_Original.py - BOTRGCN_Original style dataset loader
import torch
import numpy as np
import pandas as pd
from torch.utils.data import Dataset

class Twibot22(Dataset):
    """
    BOTRGCN_Original style dataset class that loads from preprocessed files.
    Matches the original Twibot22 class interface but uses your benchmark data.
    """
    def __init__(self, root='./processed_data/', device='cpu', process=False, save=False):
        self.root = root
        self.device = device
        self.save = save
        # process parameter is ignored since we load from preprocessed files

    def dataloader(self):
        """
        Returns preprocessed data in the exact format expected by original train.py:
        (des_tensor, tweets_tensor, num_prop, category_prop, edge_index, edge_type, labels, train_idx, val_idx, test_idx)
        """
        print("Loading preprocessed data...")

        # Load all preprocessed tensors (matching original filenames)
        des_tensor = torch.load(f"{self.root}/des_tensor.pt", map_location=self.device, weights_only=True)
        tweets_tensor = torch.load(f"{self.root}/tweets_tensor.pt", map_location=self.device, weights_only=True)
        num_prop = torch.load(f"{self.root}/num_properties_tensor.pt", map_location=self.device, weights_only=True)
        category_prop = torch.load(f"{self.root}/cat_properties_tensor.pt", map_location=self.device, weights_only=True)
        edge_index = torch.load(f"{self.root}/edge_index.pt", map_location=self.device, weights_only=True)
        edge_type = torch.load(f"{self.root}/edge_type.pt", map_location=self.device, weights_only=True)
        labels = torch.load(f"{self.root}/label.pt", map_location=self.device, weights_only=True)
        train_idx = torch.load(f"{self.root}/train_idx.pt", map_location=self.device, weights_only=True)
        val_idx = torch.load(f"{self.root}/val_idx.pt", map_location=self.device, weights_only=True)
        test_idx = torch.load(f"{self.root}/test_idx.pt", map_location=self.device, weights_only=True)

        print(f"Loaded preprocessed data:")
        print(f"  • Nodes: {des_tensor.shape[0]:,}")
        print(f"  • Features: des={des_tensor.shape}, tweets={tweets_tensor.shape}")
        print(f"  • Features: num_prop={num_prop.shape}, cat_prop={category_prop.shape}")
        print(f"  • Graph: edges={edge_index.shape[1]:,}, relations={edge_type.max().item()+1}")
        print(f"  • Splits: train={len(train_idx):,}, val={len(val_idx):,}, test={len(test_idx):,}")

        return (des_tensor, tweets_tensor, num_prop, category_prop,
                edge_index, edge_type, labels, train_idx, val_idx, test_idx)

    # Compatibility methods (not used in training but maintained for interface)
    def load_labels(self):
        return torch.load(f"{self.root}/label.pt", map_location=self.device, weights_only=True)

    def Des_Preprocess(self):
        return torch.load(f"{self.root}/des_tensor.pt", map_location=self.device, weights_only=True)

    def Des_embbeding(self):
        return torch.load(f"{self.root}/des_tensor.pt", map_location=self.device, weights_only=True)

    def tweets_preprocess(self):
        return torch.load(f"{self.root}/tweets_tensor.pt", map_location=self.device, weights_only=True)

    def tweets_embbeding(self):
        return torch.load(f"{self.root}/tweets_tensor.pt", map_location=self.device, weights_only=True)

    def num_prop_preprocess(self):
        return torch.load(f"{self.root}/num_properties_tensor.pt", map_location=self.device, weights_only=True)

    def cat_prop_preprocess(self):
        return torch.load(f"{self.root}/cat_properties_tensor.pt", map_location=self.device, weights_only=True)

    def Build_Graph(self):
        edge_index = torch.load(f"{self.root}/edge_index.pt", map_location=self.device, weights_only=True)
        edge_type = torch.load(f"{self.root}/edge_type.pt", map_location=self.device, weights_only=True)
        return edge_index, edge_type

    def train_val_test_mask(self):
        train_idx = torch.load(f"{self.root}/train_idx.pt", map_location=self.device, weights_only=True)
        val_idx = torch.load(f"{self.root}/val_idx.pt", map_location=self.device, weights_only=True)
        test_idx = torch.load(f"{self.root}/test_idx.pt", map_location=self.device, weights_only=True)
        return train_idx, val_idx, test_idx