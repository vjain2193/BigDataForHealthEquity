#!/usr/bin/env python3
"""
Bot Detection Prediction Script
Usage:
  python test_data.py \
    --csv path/to/new_data.csv \
    [--edges path/to/edges.csv] \
    [--model path/to/model.pth] \
    [--output predictions.csv] \
    [--threshold 0.42] \
    [--auto-threshold none|f1|precision90]

Notes:
- If your dataset edge types contain MORE relations than the checkpoint,
  we rebuild the model with the dataset's num_relations and load weights
  with strict=False (new relation weights are randomly initialized).
- If --auto-threshold is given and labels are present, the script can find
  an F1-optimal threshold or the smallest threshold achieving ~90% precision.
"""

import argparse
import time
from datetime import datetime
from pathlib import Path
from collections import Counter

import numpy as np
import pandas as pd
import torch

from model import BotRGCN
from Dataset import Benchmark10k
from utils import (
    infer_num_relations,
    TYPE_TO_RELATION,
    # optional helpers for dynamic thresholding
    # (they'll only be used if --auto-threshold is not "none")
    # If sklearn is missing, auto-threshold will be skipped gracefully.
    best_threshold_f1,
    threshold_for_precision,
)


# ----------------------- Device helper -----------------------

def _device():
    if torch.backends.mps.is_available():
        return "mps"
    if torch.cuda.is_available():
        return "cuda"
    return "cpu"


# ----------------------- Model loading -----------------------

def load_trained_model(model_path, device):
    """
    Load the trained model from saved checkpoint (robust to key names).
    Returns: (model, class_weights, optimal_threshold, cfg_sizes, ckpt)
    """
    print(f"Loading model from: {model_path}")
    ckpt = torch.load(model_path, map_location=device, weights_only=False)

    # Config fallbacks
    cfg = (
        ckpt.get("model_config")
        or ckpt.get("config")
        or ckpt.get("hyperparams")
        or {}
    )

    def _get(k, dflt):
        try:
            return int(cfg.get(k, dflt))
        except Exception:
            return dflt

    num_relations   = _get("num_relations", _get("num_rels", 1))
    des_size        = _get("des_size", 768)
    tweet_size      = _get("tweet_size", 768)
    num_prop_size   = _get("num_prop_size", 6)
    cat_prop_size   = _get("cat_prop_size", 11)
    embedding_dim   = _get("embedding_dimension", 128)

    model = BotRGCN(
        num_relations=num_relations,
        des_size=des_size,
        tweet_size=tweet_size,
        num_prop_size=num_prop_size,
        cat_prop_size=cat_prop_size,
        embedding_dimension=embedding_dim,
    ).to(device)

    state = ckpt.get("model_state_dict") or ckpt.get("state_dict") or ckpt
    model.load_state_dict(state, strict=False)
    model.eval()

    print("Model loaded successfully!")
    print(
        f"Model config: {{'num_relations': {num_relations}, 'des_size': {des_size}, "
        f"'tweet_size': {tweet_size}, 'num_prop_size': {num_prop_size}, "
        f"'cat_prop_size': {cat_prop_size}, 'embedding_dimension': {embedding_dim}}}"
    )

    # Threshold
    optimal_threshold = 0.5
    if "training_log" in ckpt:
        optimal_threshold = float(ckpt["training_log"].get("final_threshold", optimal_threshold))
    elif "final_threshold" in ckpt:
        optimal_threshold = float(ckpt["final_threshold"])
    print(f"Using optimized threshold from checkpoint: {optimal_threshold:.4f}")

    sizes = {
        "num_relations": num_relations,
        "des_size": des_size,
        "tweet_size": tweet_size,
        "num_prop_size": num_prop_size,
        "cat_prop_size": cat_prop_size,
        "embedding_dimension": embedding_dim,
    }
    return model, ckpt.get("class_weights", None), optimal_threshold, sizes, ckpt


def _rebuild_model_for_relations(ckpt, device, new_num_relations):
    """
    Rebuild a BotRGCN with a different num_relations and load weights (strict=False).
    Useful when the dataset has more relation types than the checkpoint.
    """
    cfg = ckpt.get("model_config") or {}
    des_size      = int(cfg.get("des_size", 768))
    tweet_size    = int(cfg.get("tweet_size", 768))
    num_prop_size = int(cfg.get("num_prop_size", 6))
    cat_prop_size = int(cfg.get("cat_prop_size", 11))
    emb_dim       = int(cfg.get("embedding_dimension", 128))

    model = BotRGCN(
        num_relations=new_num_relations,
        des_size=des_size,
        tweet_size=tweet_size,
        num_prop_size=num_prop_size,
        cat_prop_size=cat_prop_size,
        embedding_dimension=emb_dim,
    ).to(device)

    state = ckpt.get("model_state_dict") or ckpt.get("state_dict") or ckpt
    missing, unexpected = model.load_state_dict(state, strict=False)
    if missing:
        print(f"Note: initialized new params for added relations (missing={len(missing)} tensors).")
    if unexpected:
        print(f"Note: checkpoint had unexpected tensors: {unexpected}")
    model.eval()
    return model


# ----------------------- Probabilities & metrics -----------------------

def _prob_from_logits(logits: torch.Tensor) -> torch.Tensor:
    """
    Return P(bot) as a 1D tensor.
    Supports:
      - shape [N, 1]  -> sigmoid
      - shape [N, 2]  -> softmax[:, 1]
      - shape [N]     -> sigmoid
    """
    if logits.ndim == 1:
        return torch.sigmoid(logits)
    if logits.ndim == 2 and logits.shape[1] == 1:
        return torch.sigmoid(logits.squeeze(1))
    if logits.ndim == 2 and logits.shape[1] == 2:
        return torch.softmax(logits, dim=1)[:, 1]
    return torch.sigmoid(logits.squeeze(-1))


def _evaluate_and_save(y_true, y_score, threshold, out_stem, split_name="all"):
    """
    Compute metrics and (best-effort) save ROC/PR data. Returns a dict of metrics.
    Never fails the whole block just because curve saving had an issue.
    """
    import json

    y_true  = np.asarray(y_true).astype(int).ravel()
    y_score = np.asarray(y_score).astype(float).ravel()

    if y_true.shape[0] != y_score.shape[0]:
        raise ValueError(f"Length mismatch: y_true={y_true.shape[0]} vs y_score={y_score.shape[0]}")

    y_pred = (y_score >= float(threshold)).astype(int)

    try:
        from sklearn.metrics import (
            accuracy_score, precision_score, recall_score, f1_score,
            roc_auc_score, average_precision_score, roc_curve,
            precision_recall_curve, confusion_matrix
        )
    except Exception as e:
        print(f"Note: Skipping metrics due to missing scikit-learn: {e}")
        return None

    metrics = {}
    # Thresholded metrics
    metrics["accuracy"]  = float(accuracy_score(y_true, y_pred))
    metrics["precision"] = float(precision_score(y_true, y_pred, zero_division=0))
    metrics["recall"]    = float(recall_score(y_true, y_pred, zero_division=0))
    metrics["f1"]        = float(f1_score(y_true, y_pred, zero_division=0))

    # ---- ROC-AUC + CSV (safe) ----
    metrics["roc_auc"] = float(roc_auc_score(y_true, y_score))
    fpr, tpr, roc_th = roc_curve(y_true, y_score)
    try:
        thr_padded = np.append(roc_th, np.nan)
        min_len = min(len(fpr), len(tpr), len(thr_padded))
        roc_df = pd.DataFrame({
            "fpr": fpr[:min_len],
            "tpr": tpr[:min_len],
            "threshold": thr_padded[:min_len],
        })
        roc_df.to_csv(f"{out_stem}_roc_curve_{split_name}.csv", index=False)
    except Exception as e:
        print(f"Warning: could not save ROC curve ({split_name}): {e}")

    # ---- PR-AUC + CSV (safe) ----
    metrics["pr_auc"] = float(average_precision_score(y_true, y_score))
    prec, rec, _ = precision_recall_curve(y_true, y_score)
    try:
        min_len = min(len(prec), len(rec))
        pr_df = pd.DataFrame({
            "precision": np.asarray(prec)[:min_len],
            "recall":    np.asarray(rec)[:min_len],
        })
        pr_df.to_csv(f"{out_stem}_pr_curve_{split_name}.csv", index=False)
    except Exception as e:
        print(f"Warning: could not save PR curve ({split_name}): {e}")

    # Confusion matrix
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    metrics.update({"tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn)})

    # Optional: save PNGs if matplotlib is present
    try:
        import matplotlib.pyplot as plt
        # ROC
        if len(np.unique(y_true)) == 2:
            plt.figure()
            plt.plot(fpr, tpr, label=f"ROC AUC={metrics['roc_auc']:.3f}")
            plt.plot([0, 1], [0, 1], linestyle="--", linewidth=1)
            plt.xlabel("FPR"); plt.ylabel("TPR"); plt.title(f"ROC ({split_name})")
            plt.legend(loc="lower right"); plt.tight_layout()
            plt.savefig(f"{out_stem}_roc_{split_name}.png", dpi=150); plt.close()
        # PR
        plt.figure()
        plt.plot(rec, prec, label=f"PR AUC={metrics['pr_auc']:.3f}")
        plt.xlabel("Recall"); plt.ylabel("Precision"); plt.title(f"PR ({split_name})")
        plt.legend(loc="lower left"); plt.tight_layout()
        plt.savefig(f"{out_stem}_pr_{split_name}.png", dpi=150); plt.close()
    except Exception:
        pass  # plotting optional

    # Save metrics JSON
    try:
        with open(f"{out_stem}_metrics_{split_name}.json", "w") as f:
            json.dump({"threshold": float(threshold), **metrics}, f, indent=2)
    except Exception as e:
        print(f"Warning: could not save {split_name} metrics json: {e}")

    return metrics


# ----------------------- Main prediction -----------------------

def predict_new_data(
    csv_path,
    edges_path=None,
    model_path="trained_bot_detection_model_optimized.pth",
    output_path=None,
    custom_threshold=None,
    auto_threshold="none",  # "none" | "f1" | "precision90"
    batch_size=None,
):
    """Predict bot/human labels for new data"""
    start_time = time.time()
    print("\n" + "=" * 80)
    print(f"BOT DETECTION PREDICTION - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)

    device = _device()
    print(f"Using device: {device}")

    # Load the trained model
    model, class_weights, optimal_threshold, sizes, ckpt = load_trained_model(model_path, device)

    # Use custom threshold if provided
    threshold = float(custom_threshold) if custom_threshold is not None else float(optimal_threshold)
    print(f"Initial prediction threshold (pre-auto): {threshold:.4f}\n")

    # Load and process the new data
    print(f"Loading new data from: {csv_path}")
    if edges_path:
        print(f"Using edges from: {edges_path}")
    else:
        print("No edges file provided - using mention/reply edges derived from CSV")

    # File size (for info)
    file_size_gb = Path(csv_path).stat().st_size / (1024 ** 3)
    print(f"Input file size: {file_size_gb:.2f} GB")

    try:
        # Dataset handles CSV/token, split normalization, and graph building
        data = Benchmark10k(
            csv_path=csv_path,
            device=device,
            save=False,                 # don't persist in predict runs
            include_text_features=True, # set False to skip text embeddings
            edges_csv_path=edges_path,  # optional override
        )

        # Prefer the clean accessor; fallback to your existing method if needed
        if hasattr(data, "get_all_tensors"):
            (
                des_tensor, tweets_tensor, num_prop, category_prop,
                edge_index, edge_type, labels, train_idx, val_idx, test_idx
            ) = data.get_all_tensors()
        else:
            (
                des_tensor, tweets_tensor, num_prop, category_prop,
                edge_index, edge_type, labels, train_idx, val_idx, test_idx
            ) = data.dataloader()

        # ---- Relation diagnostics & auto-adaptation ----
        data_num_rels = infer_num_relations(edge_type)
        rel_counts = Counter(edge_type.cpu().numpy().tolist())
        print("\nEdge type distribution (dataset):")
        for t, c in sorted(rel_counts.items()):
            name = TYPE_TO_RELATION.get(int(t), str(t))
            print(f"  {name:<18} -> {c:,}")
        print(f"num_relations (dataset) = {data_num_rels}  •  num_relations (model) = {sizes['num_relations']}")

        if data_num_rels > sizes["num_relations"]:
            print("\nWARNING: dataset has MORE relation types than the checkpoint model.")
            print("Rebuilding model with the larger num_relations and loading weights (strict=False).")
            model = _rebuild_model_for_relations(ckpt, device, data_num_rels)

        # Move to device
        des_tensor    = des_tensor.to(device)
        tweets_tensor = tweets_tensor.to(device)
        num_prop      = num_prop.to(device)
        category_prop = category_prop.to(device)
        edge_index    = edge_index.to(device)
        edge_type     = edge_type.to(device)

        data_load_time = time.time() - start_time
        print(f"\nData loaded successfully in {data_load_time:.2f} seconds!")
        print(f"Users (N): {des_tensor.shape[0]:,}")
        print(f"Description embeddings: {des_tensor.shape}")
        print(f"Tweet embeddings:       {tweets_tensor.shape}")
        print(f"Numeric properties:     {num_prop.shape}")
        print(f"Categorical properties: {category_prop.shape}")
        print(f"Edge index:             {edge_index.shape}")
        mem_est = (des_tensor.numel() + tweets_tensor.numel()) * 4 / (1024 ** 3)
        print(f"Memory usage estimate (text only): ~{mem_est:.2f} GB")

    except Exception as e:
        print(f"Error loading data: {e}")
        return None

    # -------------------- Feature Normalization (Load Scalers) --------------------
    print("\nLoading feature scalers from training...")
    scaler_dir = Path("./scalers")
    try:
        import pickle
        from sklearn.preprocessing import RobustScaler

        # Load and apply numerical scaler
        if (scaler_dir / "num_scaler.pkl").exists():
            with open(scaler_dir / "num_scaler.pkl", 'rb') as f:
                num_scaler = pickle.load(f)
            num_prop_np = num_prop.cpu().numpy()
            num_prop_normalized = num_scaler.transform(num_prop_np)
            num_prop = torch.tensor(num_prop_normalized, device=device, dtype=torch.float32)
            print("Applied numerical feature normalization")
        else:
            print("Warning: num_scaler.pkl not found, using unnormalized features")

        # Load and apply categorical scaler
        if (scaler_dir / "cat_scaler.pkl").exists():
            with open(scaler_dir / "cat_scaler.pkl", 'rb') as f:
                cat_scaler = pickle.load(f)
            cat_prop_np = category_prop.cpu().numpy()
            cat_prop_normalized = cat_scaler.transform(cat_prop_np)
            category_prop = torch.tensor(cat_prop_normalized, device=device, dtype=torch.float32)
            print("Applied categorical feature normalization")
        else:
            print("Warning: cat_scaler.pkl not found, using unnormalized features")
    except Exception as e:
        print(f"Warning: Could not load scalers ({e}), proceeding without normalization")

    # -------------------- Test-Time Augmentation (TTA) --------------------
    print("\nMaking predictions with test-time augmentation...")
    prediction_start = time.time()

    n_tta = 5  # Number of TTA passes
    all_probs = []

    with torch.no_grad():
        # 1. Original graph (no augmentation)
        logits = model(des_tensor, tweets_tensor, num_prop, category_prop, edge_index, edge_type)
        all_probs.append(_prob_from_logits(logits).cpu().numpy())

        # 2. Multiple passes with random edge dropout
        for tta_i in range(n_tta - 1):
            # Drop 20% of edges randomly
            num_edges = edge_index.shape[1]
            keep_mask = torch.rand(num_edges, device=device) > 0.2
            edge_index_aug = edge_index[:, keep_mask]
            edge_type_aug = edge_type[keep_mask]

            logits_aug = model(des_tensor, tweets_tensor, num_prop, category_prop, edge_index_aug, edge_type_aug)
            all_probs.append(_prob_from_logits(logits_aug).cpu().numpy())

    # Average predictions across all TTA passes
    bot_prob = np.mean(all_probs, axis=0)
    prediction_time = time.time() - prediction_start
    print(f"Predictions completed (with {n_tta}x TTA) in {prediction_time:.2f} seconds")

    # If requested and labels exist, pick a fresh threshold
    if auto_threshold and auto_threshold.lower() != "none":
        try:
            y_true_all = np.asarray(labels.cpu().numpy()).astype(int)
            if auto_threshold.lower() == "f1":
                threshold = best_threshold_f1(y_true_all, bot_prob)
                print(f"\nAuto-threshold (F1-optimal on provided labels): {threshold:.4f}")
            elif auto_threshold.lower() == "precision90":
                threshold = threshold_for_precision(y_true_all, bot_prob, prec_target=0.90)
                print(f"\nAuto-threshold (≥90% precision on provided labels): {threshold:.4f}")
        except Exception as e:
            print(f"\nNote: auto-thresholding skipped (missing labels or sklearn): {e}")

    # Additional adaptive threshold suggestion based on prediction distribution
    if "label" in data.df.columns:
        print(f"\n{'='*60}")
        print("ADAPTIVE THRESHOLD ANALYSIS")
        print(f"{'='*60}")
        print(f"Current threshold: {threshold:.4f}")
        print(f"Average predicted probability: {bot_prob.mean():.4f}")
        print(f"Median predicted probability: {np.median(bot_prob):.4f}")

        # Try different thresholds and report metrics
        y_true = np.asarray(labels.cpu().numpy()).astype(int)

        print("\nTrying different thresholds:")
        for test_thr in [0.1, 0.2, 0.3, 0.4, 0.5]:
            preds = (bot_prob >= test_thr).astype(int)
            from sklearn.metrics import f1_score, precision_score, recall_score, accuracy_score
            acc = accuracy_score(y_true, preds)
            prec = precision_score(y_true, preds, zero_division=0)
            rec = recall_score(y_true, preds, zero_division=0)
            f1 = f1_score(y_true, preds, zero_division=0)
            print(f"  Threshold={test_thr:.1f} -> Acc={acc:.3f}  Prec={prec:.3f}  Rec={rec:.3f}  F1={f1:.3f}")

        # Find best F1 threshold
        from sklearn.metrics import f1_score
        best_thr = 0.5
        best_f1 = 0
        for test_thr in np.linspace(0.05, 0.95, 91):
            preds = (bot_prob >= test_thr).astype(int)
            f1 = f1_score(y_true, preds, zero_division=0)
            if f1 > best_f1:
                best_f1 = f1
                best_thr = test_thr
        print(f"\nBest F1 threshold for this dataset: {best_thr:.4f} (F1={best_f1:.4f})")
        print(f"Consider using: --threshold {best_thr:.4f}")
        threshold = best_thr  # Use the optimal threshold

    # Thresholded predictions
    predictions_optimized = (bot_prob >= threshold).astype(np.int64)
    predictions_default   = (bot_prob >= 0.5).astype(np.int64)

    # Results dataframe (aligned to the dataset's user order)
    user_ids = getattr(data, "user_ids_ordered", list(range(len(predictions_optimized))))

    results = pd.DataFrame({
        "user_id": user_ids,
        "predicted_label": np.where(predictions_optimized == 1, "bot", "human"),
        "prediction_numeric": predictions_optimized,
        "prediction_default": np.where(predictions_default == 1, "bot", "human"),
        "bot_probability": bot_prob,
        "threshold_used": threshold,
        "confidence": np.maximum(bot_prob, 1.0 - bot_prob),
        "prediction_timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    })

    # Optional: enrich with a few columns from the unique user table if present
    try:
        unique_users = (
            data.df.drop_duplicates(subset=["user_id"], keep="first").copy()
            if hasattr(data, "df") else
            pd.read_csv(csv_path, low_memory=False).drop_duplicates(subset=["user_id"], keep="first")
        )
        unique_users = unique_users.set_index(unique_users["user_id"].astype(str)).reindex(user_ids)

        useful_cols = [
            "user_username", "screen_name", "user_name",
            "user_followers_count", "user_following_count",
            "followers_count", "friends_count",
            "description", "user_profile", "user_verified"
        ]
        for col in useful_cols:
            if col in unique_users.columns:
                results[col] = unique_users[col].values
    except Exception:
        print("Note: could not enrich results with user metadata (non-fatal).")

    # Summary (counts only)
    bot_count          = int((predictions_optimized == 1).sum())
    human_count        = int((predictions_optimized == 0).sum())
    bot_count_default  = int((predictions_default == 1).sum())
    total_time         = time.time() - start_time

    print("\n" + "=" * 60)
    print("PREDICTION SUMMARY")
    print("=" * 60)
    print(f"Total users processed: {len(predictions_optimized):,}")
    print(f"Processing time:       {total_time:.2f} seconds")
    print(f"Processing rate:       {len(predictions_optimized)/max(total_time,1):.0f} users/second")
    print(f"\nResults with threshold ({threshold:.3f}):")
    print(f"  Predicted bots:   {bot_count:,} ({bot_count/len(predictions_optimized)*100:.1f}%)")
    print(f"  Predicted humans: {human_count:,} ({human_count/len(predictions_optimized)*100:.1f}%)")
    print("\nResults with default threshold (0.5):")
    print(f"  Predicted bots:   {bot_count_default:,} ({bot_count_default/len(predictions_default)*100:.1f}%)")
    print("\nStatistics:")
    print(f"  Average bot probability: {bot_prob.mean():.3f}")
    print(f"  Median bot probability:  {np.median(bot_prob):.3f}")
    print(f"  Average confidence:      {results['confidence'].mean():.3f}")
    hi_conf = (results["confidence"] > 0.9).sum()
    print(f"  High confidence (>0.9):  {hi_conf:,} ({(hi_conf/len(results))*100:.1f}%)")

    # Top bot candidates
    print("\nTop 10 Bot Candidates:")
    top_bots = results.nlargest(10, "bot_probability")
    for _, row in top_bots.iterrows():
        username = None
        for col in ("user_username", "screen_name", "user_name"):
            if col in results.columns and pd.notna(row.get(col, None)):
                username = row[col]
                break
        user_info = f"User {row['user_id']}" + (f" (@{username})" if username else "")
        print(f"  {user_info}: {row['bot_probability']:.3f} probability")

    # Probability histogram buckets
    print("\nBot Probability Distribution:")
    buckets = [(0.0, 0.1),(0.1, 0.3),(0.3, 0.7),(0.7, 0.9),(0.9, 1.0)]
    for lo, hi in buckets:
        cnt = int(((bot_prob >= lo) & (bot_prob < hi if hi < 1.0 else bot_prob <= hi)).sum())
        print(f"  {lo:.1f}-{hi:.1f}: {cnt:,} users")

    # Output paths
    print("\nSaving results...")
    if output_path:
        final_output_path = output_path
    else:
        base_name = Path(csv_path).stem
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        final_output_path = f"{base_name}_predictions_{timestamp}.csv"

    results.to_csv(final_output_path, index=False)
    output_size_mb = Path(final_output_path).stat().st_size / (1024 ** 2)
    print(f"Results saved to: {final_output_path}")
    print(f"Output file size: {output_size_mb:.2f} MB")

    # Save summary
    summary_path = final_output_path.replace(".csv", "_summary.txt")
    with open(summary_path, "w") as f:
        f.write("Bot Detection Prediction Summary\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Input file: {csv_path}\n")
        f.write(f"Model: {model_path}\n")
        f.write(f"Threshold: {threshold:.4f}\n\n")
        f.write(f"Total users: {len(predictions_optimized):,}\n")
        f.write(f"Predicted bots: {bot_count:,} ({bot_count/len(predictions_optimized)*100:.1f}%)\n")
        f.write(f"Predicted humans: {human_count:,} ({human_count/len(predictions_optimized)*100:.1f}%)\n")
        f.write(f"Average bot probability: {bot_prob.mean():.3f}\n")
        f.write(f"Processing time: {total_time:.2f} seconds\n")
    print(f"Summary saved to: {summary_path}")

    # =========================
    # METRICS (if labels exist)
    # =========================
    print("\nChecking for ground-truth labels to compute metrics...")
    metrics_any = False
    out_stem = Path(final_output_path).with_suffix("").as_posix()

    try:
        y_true_all = np.asarray(labels.cpu().numpy()).astype(int)

        # Evaluate on ALL users
        m_all_opt = _evaluate_and_save(y_true_all, bot_prob, threshold, out_stem, split_name="all_opt")
        m_all_def = _evaluate_and_save(y_true_all, bot_prob, 0.5,      out_stem, split_name="all_def")
        if m_all_opt:
            metrics_any = True
            print("\nMETRICS (ALL USERS)")
            print(f"  Threshold={threshold:.3f} -> "
                  f"Acc={m_all_opt['accuracy']:.3f}  Prec={m_all_opt['precision']:.3f}  "
                  f"Rec={m_all_opt['recall']:.3f}  F1={m_all_opt['f1']:.3f}  "
                  f"ROC-AUC={m_all_opt['roc_auc']:.3f}  PR-AUC={m_all_opt['pr_auc']:.3f}")
            print(f"  Threshold=0.500 -> "
                  f"Acc={m_all_def['accuracy']:.3f}  Prec={m_all_def['precision']:.3f}  "
                  f"Rec={m_all_def['recall']:.3f}  F1={m_all_def['f1']:.3f}  "
                  f"ROC-AUC={m_all_def['roc_auc']:.3f}  PR-AUC={m_all_def['pr_auc']:.3f}")

        # Evaluate on TEST split only (if mask not empty)
        test_idx_np = np.asarray(test_idx.cpu().numpy(), dtype=bool)
        if test_idx_np.any():
            y_true_test = y_true_all[test_idx_np]
            y_score_test = bot_prob[test_idx_np]
            m_test_opt = _evaluate_and_save(y_true_test, y_score_test, threshold, out_stem, split_name="test_opt")
            m_test_def = _evaluate_and_save(y_true_test, y_score_test, 0.5,      out_stem, split_name="test_def")
            if m_test_opt:
                metrics_any = True
                print("\nMETRICS (TEST SPLIT)")
                print(f"  Threshold={threshold:.3f} -> "
                      f"Acc={m_test_opt['accuracy']:.3f}  Prec={m_test_opt['precision']:.3f}  "
                      f"Rec={m_test_opt['recall']:.3f}  F1={m_test_opt['f1']:.3f}  "
                      f"ROC-AUC={m_test_opt['roc_auc']:.3f}  PR-AUC={m_test_opt['pr_auc']:.3f}")
                print(f"  Threshold=0.500 -> "
                      f"Acc={m_test_def['accuracy']:.3f}  Prec={m_test_def['precision']:.3f}  "
                      f"Rec={m_test_def['recall']:.3f}  F1={m_test_def['f1']:.3f}  "
                      f"ROC-AUC={m_test_def['roc_auc']:.3f}  PR-AUC={m_test_def['pr_auc']:.3f}")

    except Exception as e:
        print(f"Could not compute metrics (labels missing or error): {e}")

    if metrics_any:
        print("\nMetric files saved alongside your predictions:")
        print(f"  - {out_stem}_metrics_all_opt.json / _all_def.json")
        print(f"  - {out_stem}_metrics_test_opt.json / _test_def.json")
        print(f"  - {out_stem}_roc_curve_*.csv and {out_stem}_pr_curve_*.csv (and PNGs if matplotlib available)")
    else:
        print("No metrics computed (no labels or scikit-learn not available).")

    return results


# ----------------------- CLI -----------------------

def main():
    parser = argparse.ArgumentParser(description="Predict bot/human labels using trained model")
    parser.add_argument("--csv", required=True, help="Path to CSV file or dataset token")
    parser.add_argument("--edges", default=None, help="Optional path to edges CSV file")
    parser.add_argument("--model", default="trained_bot_detection_model_optimized.pth",
                        help="Path to trained model file")
    parser.add_argument("--output", default=None, help="Output path for predictions CSV")
    parser.add_argument("--threshold", type=float, default=None,
                        help="Custom threshold (overrides optimized threshold)")
    parser.add_argument("--auto-threshold", choices=["none", "f1", "precision90"], default="none",
                        help="Pick a threshold using labels if available (default: none)")
    parser.add_argument("--batch-size", type=int, default=None,
                        help="(Optional) batch size for memory management (unused for now)")

    args = parser.parse_args()

    # Basic file checks (only if args.csv is a path)
    if Path(args.csv).suffix.lower() == ".csv" and not Path(args.csv).exists():
        print(f"Error: CSV file not found: {args.csv}")
        return
    if not Path(args.model).exists():
        print(f"Error: Model file not found: {args.model}")
        print("Please train the model first.")
        return
    if args.edges and not Path(args.edges).exists():
        print(f"Error: Edges file not found: {args.edges}")
        return

    # Run
    results = predict_new_data(
        csv_path=args.csv,
        edges_path=args.edges,
        model_path=args.model,
        output_path=args.output,
        custom_threshold=args.threshold,
        auto_threshold=args.auto_threshold,
        batch_size=getattr(args, "batch_size", None),
    )
    if results is not None:
        print("\nPrediction completed successfully!")


if __name__ == "__main__":
    main()
