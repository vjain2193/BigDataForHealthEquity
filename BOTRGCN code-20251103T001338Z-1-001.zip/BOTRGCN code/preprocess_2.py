# preprocess_2.py - BOTRGCN_Original structure for feature extraction (robust to cache shape)
import os
import pandas as pd
import numpy as np
import torch
from tqdm import tqdm
from datetime import datetime as dt
from transformers import pipeline

print('Loading user mapping from preprocess_1...')

# ---- Load mapping saved by preprocess_1 (be tolerant of torch version) ----
try:
    user_mapping = torch.load('./processed_data/user_mapping.pt', weights_only=True)
except TypeError:
    user_mapping = torch.load('./processed_data/user_mapping.pt')
user_ids  = user_mapping["user_ids"]            # list[str] in fixed order
uid_index = user_mapping["uid_index"]           # dict[str -> int]
csv_path  = user_mapping["csv_path"]

EXPECTED_N = len(user_ids)

# ---- Small helper: reuse cache only if shape[0] == EXPECTED_N ----
def _load_or_recompute(path, expected_n, build_fn):
    if os.path.exists(path):
        t = torch.load(path, map_location="cpu")
        if isinstance(t, torch.Tensor) and t.shape[0] == expected_n:
            return t
        print(f"[warn] {os.path.basename(path)} has shape {tuple(t.shape)}; expected ({expected_n}, ·). Recomputing...")
    t = build_fn()
    torch.save(t, path)
    return t

# ---- Load CSV and restrict to the stratified users decided in preprocess_1 ----
print(f'Loading CSV data from: {csv_path}')
df = pd.read_csv(csv_path)
df["user_id"] = (
    df["user_id"].astype(str)
      .apply(lambda x: x.strip().lstrip('u').rstrip('.0'))
)

# Keep a 1-row-per-user table for profile/props; preserve user_ids order
user_df = (
    df[df["user_id"].isin(user_ids)]
    .drop_duplicates(subset=["user_id"], keep="first")
    .set_index("user_id")
    .reindex(user_ids)
    .reset_index()
)
print(f'Filtered to {len(user_df)} stratified users (from {len(df)} total rows)')
print(f'Processing features for {EXPECTED_N} users...')

# -------------------- Feature 1: Description embeddings --------------------
print('Running feature1 embedding (descriptions)')
def _build_des():
    descriptions = []
    up = user_df["user_profile"] if "user_profile" in user_df.columns else pd.Series(['']*EXPECTED_N)
    up = up.fillna('').astype(str)
    for s in up.tolist():
        descriptions.append(s if s else 'None')

    # distilroberta for speed
    device = 0 if torch.cuda.is_available() else -1  # mps: pipeline uses CPU fallback
    feat = pipeline(
        'feature-extraction',
        model="distilroberta-base",
        tokenizer="distilroberta-base",
        device=device
    )
    vecs = []
    for text in tqdm(descriptions):
        text = str(text)[:600]
        out = torch.tensor(feat(text, truncation=True, max_length=512))
        # mean pool over sequence dim
        seq = out[0] if out.ndim == 3 else out
        vecs.append(seq.mean(dim=0))
    return torch.stack(vecs, 0)

des_tensor = _load_or_recompute("./processed_data/des_tensor.pt", EXPECTED_N, _build_des)
print('Finished')

# -------------------- Feature 2: Tweet embeddings (avg up to 20) --------------------
print('Running feature2 embedding (tweets)')
def _build_tweets():
    # gather up to 20 tweets per user (ALL rows in df)
    tweets_per_user = []
    for uid in user_ids:
        tweets = df.loc[df["user_id"] == uid, "tweet_text"].fillna("").astype(str).tolist()
        tweets_per_user.append(tweets[:20])

    device = 0 if torch.cuda.is_available() else -1
    feat = pipeline(
        'feature-extraction',
        model="roberta-base",
        tokenizer="roberta-base",
        device=device
    )

    H = 768
    user_vecs = []
    for tws in tqdm(tweets_per_user):
        if not tws or all(not t for t in tws):
            user_vecs.append(torch.zeros(H))
            continue
        s, c = None, 0
        for tw in tws:
            if not tw.strip():
                continue
            tw = tw[:500]
            out = torch.tensor(feat(tw, truncation=True, max_length=512))
            seq = out[0] if out.ndim == 3 else out
            v = seq.mean(dim=0)
            s = v if s is None else (s + v)
            c += 1
        user_vecs.append((s / max(c, 1)) if s is not None else torch.zeros(H))
    return torch.stack(user_vecs, 0)

tweets_tensor = _load_or_recompute("./processed_data/tweets_tensor.pt", EXPECTED_N, _build_tweets)
print('Finished')

# -------------------- Feature 3: Numeric properties --------------------
print('Processing feature3...   ', end='')
def _build_num():
    base_date = dt.strptime("Tue Sep 1 00:00:00 +0000 2020", "%a %b %d %X %z %Y")

    def colf(name, default=0):
        if name in user_df.columns:
            s = user_df[name].fillna(default)
            try:
                return s.astype(float).values
            except Exception:
                return pd.to_numeric(s, errors="coerce").fillna(default).values
        return np.full(EXPECTED_N, default, dtype=float)

    followers = colf("user_followers_count", 0)
    friends   = colf("user_following_count", 0)
    listed    = colf("user_listed_count",   0)  # used as favourites proxy (as in your code)
    statuses  = colf("user_tweets_count",   0)

    usernames = (user_df["user_username"].fillna('').astype(str).values
                 if "user_username" in user_df.columns else np.array(['']*EXPECTED_N))
    screen_len = np.vectorize(len)(usernames).astype(float)

    # active_days from created_at
    created = (user_df["user_created_at"] if "user_created_at" in user_df.columns
               else pd.Series(['']*EXPECTED_N))
    active_days = []
    for val in created:
        try:
            if pd.notna(val) and str(val):
                d = pd.to_datetime(val)
                if d.tzinfo is None:
                    d = d.tz_localize(base_date.tzinfo)
                active_days.append(max((base_date - d).days, 0))
            else:
                active_days.append(0)
        except Exception:
            active_days.append(0)
    active_days = np.asarray(active_days, dtype=float)

    def z(x):
        x = np.asarray(x, dtype=np.float32)
        return (x - x.mean()) / (x.std() + 1e-8)

    feats = np.stack([
        z(followers), z(friends), z(listed), z(statuses), z(screen_len), z(active_days)
    ], axis=1).astype(np.float32)
    return torch.tensor(feats, dtype=torch.float32)

num_prop = _load_or_recompute("./processed_data/num_properties_tensor.pt", EXPECTED_N, _build_num)
print('Finished')

# -------------------- Feature 4: Categorical properties --------------------
print('Processing feature4...   ', end='')
def _build_cat():
    cats = []
    ver = (user_df["user_verified"].fillna(False).astype(bool).astype(int).values
           if "user_verified" in user_df.columns else np.zeros(EXPECTED_N, dtype=int))
    pinned = (user_df["user_pinned_tweet_id"].notna().astype(int).values
              if "user_pinned_tweet_id" in user_df.columns else np.zeros(EXPECTED_N, dtype=int))
    has_loc = (user_df["user_place"].notna().astype(int).values
               if "user_place" in user_df.columns else np.zeros(EXPECTED_N, dtype=int))

    for i in range(EXPECTED_N):
        row = [int(ver[i]), int(pinned[i]), int(has_loc[i])]
        row += [0]*8  # pad to 11 dims to match model
        cats.append(row)
    return torch.tensor(cats, dtype=torch.float32)

category_properties = _load_or_recompute("./processed_data/cat_properties_tensor.pt", EXPECTED_N, _build_cat)
print('Finished')

# -------------------- Summary --------------------
print('Finished preprocessing step 2:')
print(f'  • Description embeddings: {des_tensor.shape}')
print(f'  • Tweet embeddings: {tweets_tensor.shape}')
print(f'  • Numerical properties: {num_prop.shape}')
print(f'  • Categorical properties: {category_properties.shape}')
print(f'  • All features saved to: ./processed_data/')

# Sanity assert: all first dims aligned
assert des_tensor.shape[0] == EXPECTED_N,  "des_tensor first dim mismatch"
assert tweets_tensor.shape[0] == EXPECTED_N, "tweets_tensor first dim mismatch"
assert num_prop.shape[0] == EXPECTED_N,      "num_prop first dim mismatch"
assert category_properties.shape[0] == EXPECTED_N, "cat_properties first dim mismatch"
