# preprocess.py - BOTRGCN_Original pipeline controller for benchmark data
import os

print("Starting BOTRGCN preprocessing pipeline...")
print("Step 1: Processing graph structure, labels, and splits...")
order = "python preprocess_1.py"
os.system(order)

print("Step 2: Processing text embeddings and features...")
order = "python preprocess_2.py"
os.system(order)

print("✓ Preprocessing pipeline completed!")
print("✓ Ready for training with train.py")
