# Dataset.py
import os
from datetime import datetime as dt
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from tqdm import tqdm
from transformers import pipeline

# Helpers from your repo
from dataset_tool import (
    merge,                          # reads your Benchmark CSV or token
    homo_graph_vectorize_only_user, # builds user graph + labels (mention/reply)
)

# Single source of truth for relations & id utils
from utils import (
    RELATION_TO_TYPE,      # {"mentioned":0, "replied_to":1, "co_mention":2, "co_reply":3, "same_conversation":4}
    TYPE_TO_RELATION,      # {0:"mentioned", 1:"replied_to", ...}
    norm_user_id,          # strips leading 'u', trailing '.0', etc.
    infer_num_relations,   # returns 1+max(edge_type) or 1 if empty
)


class Twibot22BenchMark(Dataset):
    """
    Mimics BOTRGCN_Original Twibot22 class but for your benchmark data.
    Simple interface matching original: dataset.dataloader() returns all tensors.
    """
    def __init__(self, root='./processed_data_benchmark/Benchmark_data_1m/', device='cpu', process=False, save=True):
        self.root = Path(root)
        self.device = device
        self.save = save

        if not self.root.exists():
            raise FileNotFoundError(f"Processed data not found at {self.root}. Run preprocessing first!")

        print(f"Loading benchmark data from: {self.root}")

    def dataloader(self):
        """
        Returns the same tuple as BOTRGCN_Original Twibot22.dataloader():
        (des_tensor, tweets_tensor, num_prop, category_prop, edge_index, edge_type, labels, train_idx, val_idx, test_idx)
        """
        # Load all tensors (matching original format)
        des_tensor = torch.load(self.root / "des_tensor.pt", map_location=self.device)
        tweets_tensor = torch.load(self.root / "tweets_tensor.pt", map_location=self.device)
        labels = torch.load(self.root / "label.pt", map_location=self.device)
        edge_index = torch.load(self.root / "edge_index.pt", map_location=self.device)
        edge_type = torch.load(self.root / "edge_type.pt", map_location=self.device)
        train_idx = torch.load(self.root / "train_idx.pt", map_location=self.device)
        val_idx = torch.load(self.root / "val_idx.pt", map_location=self.device)
        test_idx = torch.load(self.root / "test_idx.pt", map_location=self.device)

        # For compatibility, create simple num_prop and category_prop placeholders
        # (You can enhance these later if needed)
        num_nodes = des_tensor.shape[0]
        num_prop = torch.randn(num_nodes, 5, device=self.device)  # 5 numerical features
        category_prop = torch.randint(0, 2, (num_nodes, 3), device=self.device).float()  # 3 categorical features

        print(f"Loaded benchmark data:")
        print(f"  • Nodes: {num_nodes:,}")
        print(f"  • Edges: {edge_index.shape[1]:,}")
        print(f"  • Relations: {edge_type.max().item() + 1} (enhanced: 5-relation)")
        print(f"  • Train: {len(train_idx):,}, Val: {len(val_idx):,}, Test: {len(test_idx):,}")

        return (des_tensor, tweets_tensor, num_prop, category_prop,
                edge_index, edge_type, labels, train_idx, val_idx, test_idx)


class Benchmark10k(Dataset):
    """
    Inference-ready dataset that:
      - Loads a Benchmark_* CSV (or literal CSV path) via dataset_tool.merge()
      - Builds a homogeneous user graph (mention/reply) + labels
      - Optionally overrides edges from an external edges CSV (supports 5 relations)
      - Caches and returns text/num/cat features + masks in model-ready shapes
    """
    def __init__(self, csv_path: str, device='cpu', save=True,
                 include_text_features=True, edges_csv_path=None):
        self.device = device
        self.save = save
        self.include_text_features = include_text_features

        # 1) Read (normalized) CSV via merge()
        self.df = merge(csv_path, "209")

        # Normalize IDs consistently
        self.df["user_id"] = self.df["user_id"].astype(str).map(norm_user_id)

        self.csv_path = Path(csv_path).resolve()
        self.cache_dir = Path("./processed_data_benchmark") / Path(csv_path).stem
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.max_tweets_per_user = 20

        # Normalize split column
        self.df["split"] = (
            self.df["split"].astype(str)
            .str.strip().str.lower()
            .replace({"validation": "val", "valid": "val", "testing": "test", "trainning": "train"})
        )

        # 2) Build user graph + labels using the dataset token
        # The graph builder reads via merge(token), so expose token and BOTRG_DATA_DIR
        os.environ["BOTRG_DATA_DIR"] = str(Path(csv_path).resolve().parent)
        dataset_token = Path(Path(csv_path).name).stem
        self.dataset_token = dataset_token
        self.cache_dir = Path("./processed_data_benchmark") / self.dataset_token
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        (self.edge_index,
         self.edge_type,
         self.labels,
         self.uid_to_user_index,
         self.train_uid_with_label,
         self.valid_uid_with_label,
         self.test_uid_with_label) = homo_graph_vectorize_only_user(
            include_node_feature=False,
            dataset=dataset_token
        )

        # relation count even for the default (mention/reply) graph
        self.num_relations = infer_num_relations(self.edge_type)

        # 3) Freeze user-id order (align features with graph nodes)
        # Build id -> index map with normalized keys
        self._id2idx = {str(uid).lstrip('u'): int(i) for uid, i in self.uid_to_user_index.items()}
        self._users_set = set(self._id2idx.keys())

        # Deterministic user order by node index
        self.user_ids_ordered = [uid for uid, _ in sorted(self._id2idx.items(), key=lambda kv: kv[1])]

        # Build per-user table keyed by normalized ids (first row per user)
        df_first = self.df.drop_duplicates(subset=["user_id"], keep="first")
        self.user_tbl = df_first.set_index("user_id").reindex(self.user_ids_ordered)
        matched = self.user_tbl.index.notna().sum()
        print(f"[sanity] matched user rows: {matched}/{len(self.user_tbl)}")

        # Consistent labels from CSV (1=bot, 0=human; majority vote per user).
        self.labels = self._build_labels_from_csv()
        if self.labels.float().mean().item() > 0.5:
            # Safety: if inverted for some reason, flip once
            self.labels = 1 - self.labels
            print("NOTE: flipped label polarity so that 1=bot, 0=human.")

        # 4) Optional: override edges from external edges CSV ONCE (after mapping exists)
        if edges_csv_path:
            print(f"Using edges override: {edges_csv_path}")
            self._override_edges_with_edges_csv(edges_csv_path)

        # Ready. The rest of the methods create features/masks as needed.

    # ---------- Core helpers ----------

    def _build_labels_from_csv(self) -> torch.Tensor:
        """
        Build 0/1 labels per user from the CSV, enforcing 1=bot, 0=human.
        Uses majority vote if multiple rows per user exist.
        If 'label' is missing (inference-only CSV), returns zeros.
        """
        if "label" not in self.df.columns:
            return torch.zeros(len(self.user_ids_ordered), dtype=torch.long)

        s = self.df[["user_id", "label"]].copy()
        s["user_id"] = s["user_id"].astype(str).map(norm_user_id)

        # Normalize label → {0,1}
        if s["label"].dtype == object:
            s["label"] = (
                s["label"].astype(str).str.lower().str.strip()
                .map({"bot": 1, "human": 0, "1": 1, "0": 0, "true": 1, "false": 0})
            )
        else:
            s["label"] = s["label"].astype(int)

        # Heuristic safeguard (if dataset used 1=human)
        if s["label"].mean(skipna=True) > 0.5:
            s["label"] = 1 - s["label"]

        agg = (
            s.dropna(subset=["user_id"])
             .groupby("user_id")["label"].mean()
             .apply(lambda m: 1 if m >= 0.5 else 0)
        )
        arr = [int(agg.get(uid, 0)) for uid in self.user_ids_ordered]
        return torch.tensor(arr, dtype=torch.long)

    def _build_split_masks_from_csv(self):
        """
        Build boolean masks for train/val/test at user granularity.
        For inference CSVs with no splits, defaults everyone to 'test'.
        """
        s = self.df[["user_id", "split"]].copy()
        s["user_id"] = s["user_id"].astype(str).map(norm_user_id)
        s["split"] = (
            s["split"].astype(str).str.lower().str.strip()
            .replace({"validation": "val", "valid": "val", "testing": "test"})
        )

        def resolve(ss):
            vals = set(ss)
            if "train" in vals: return "train"
            if "val"   in vals: return "val"
            if "test"  in vals: return "test"
            return "train"

        per_user_split = s.groupby("user_id")["split"].apply(resolve)

        train_mask = torch.tensor(
            [per_user_split.get(uid, "train") == "train" for uid in self.user_ids_ordered],
            dtype=torch.bool
        )
        val_mask = torch.tensor(
            [per_user_split.get(uid, "train") == "val" for uid in self.user_ids_ordered],
            dtype=torch.bool
        )
        test_mask = torch.tensor(
            [per_user_split.get(uid, "train") == "test" for uid in self.user_ids_ordered],
            dtype=torch.bool
        )
        return train_mask, val_mask, test_mask

    def _override_edges_with_edges_csv(self, edges_csv_path: str):
        """
        Override current graph with an external edges CSV.
        Supports case-insensitive columns:
          - source_id, target_id  (required)
          - relation / edge_type / type  (optional)
        Relation mapping -> int type comes from utils.RELATION_TO_TYPE.
        If edge_type column is already numeric, it's used directly.
        """
        import pandas as pd
        p = Path(edges_csv_path)
        if not p.exists():
            print(f"edges override: file not found: {p}")
            return

        # Ensure mappings exist (call order safety)
        if not hasattr(self, "_id2idx") or not hasattr(self, "_users_set"):
            if hasattr(self, "uid_to_user_index") and self.uid_to_user_index:
                self._id2idx = {str(uid).lstrip('u'): int(i) for uid, i in self.uid_to_user_index.items()}
                self._users_set = set(self._id2idx.keys())
            else:
                user_ids = (
                    self.df["user_id"].astype(str).map(norm_user_id)
                    if "user_id" in self.df.columns else pd.Series([], dtype=str)
                )
                uniq = user_ids.dropna().unique().tolist()
                self._id2idx = {uid: i for i, uid in enumerate(uniq)}
                self._users_set = set(self._id2idx.keys())

        # Resolve actual header names (case-insensitive)
        head = pd.read_csv(p, nrows=0)
        colmap = {c.lower(): c for c in head.columns}

        need = {"source_id", "target_id"}
        if not need.issubset(set(colmap.keys())):
            print("edges override: missing required columns; need source_id,target_id (any case). Ignoring.")
            return

        src_col = colmap["source_id"]
        dst_col = colmap["target_id"]
        rel_col = colmap.get("relation") or colmap.get("edge_type") or colmap.get("type")

        usecols = [src_col, dst_col] + ([rel_col] if rel_col else [])
        df = pd.read_csv(p, usecols=usecols)

        # Normalize IDs
        for c in [src_col, dst_col]:
            df[c] = df[c].astype(str).map(norm_user_id)

        # Keep only edges where both endpoints exist in this dataset
        mask = df[src_col].isin(self._users_set) & df[dst_col].isin(self._users_set)
        skipped_not_in_users = int((~mask).sum())
        df = df[mask]

        # Determine edge_type (int) from relation / edge_type / type
        skipped_unknown_rel = 0
        if rel_col and rel_col in df.columns:
            if pd.api.types.is_numeric_dtype(df[rel_col]):
                et = df[rel_col].astype(int).to_numpy()
            else:
                df[rel_col] = df[rel_col].astype(str).str.strip().str.lower()
                bad = ~df[rel_col].isin(RELATION_TO_TYPE.keys())
                skipped_unknown_rel = int(bad.sum())
                df = df[~bad]
                et = df[rel_col].map(RELATION_TO_TYPE).astype(int).to_numpy()
        else:
            # No relation column: default to 'mentioned' (id 0)
            et = np.zeros(len(df), dtype=int)

        if len(df) == 0:
            print(
                "edges.csv override produced 0 edges — keeping original edges. "
                f"(skipped_not_in_users={skipped_not_in_users}, skipped_unknown_rel={skipped_unknown_rel})"
            )
            return

        # Indexify using the dataset’s user order
        s_idx = df[src_col].map(self._id2idx).astype(int).to_numpy()
        t_idx = df[dst_col].map(self._id2idx).astype(int).to_numpy()
        edge_index = torch.from_numpy(np.vstack([s_idx, t_idx]).astype(np.int64))
        edge_type  = torch.from_numpy(et.astype(np.int64))

        # Override in-memory graph + relation count
        self.edge_index = edge_index
        self.edge_type  = edge_type
        self.num_relations = infer_num_relations(self.edge_type)

        # Log relation counts (friendly names if possible)
        rel_counts = pd.Series(et).map(TYPE_TO_RELATION).value_counts().to_dict()
        print(
            f"edges.csv override accepted {len(df)} edges "
            f"(skipped_not_in_users={skipped_not_in_users}, skipped_unknown_rel={skipped_unknown_rel}) "
            f"by relation: {rel_counts}  • num_relations={self.num_relations}"
        )

    # ---------- Public API used by test_data.py ----------

    def load_labels(self):
        # Already built in __init__ (1=bot, 0=human or zeros for inference-only)
        return self.labels.to(self.device)

    def Des_Preprocess(self):
        print('Loading raw feature1...', end='   ')
        path = self.cache_dir / "description.npy"
        os.makedirs('./processed_data_benchmark', exist_ok=True)

        if not os.path.exists(path):
            desc_series = self.user_tbl.get(
                "user_profile",
                pd.Series([""] * len(self.user_tbl), index=self.user_tbl.index)
            )
            desc = desc_series.fillna("").astype(str).tolist()
            np.save(path, np.array(desc, dtype=object))
        else:
            desc = np.load(path, allow_pickle=True)
        print('Finished')
        return desc

    def Des_embbeding(self):
        print('Running feature1 embedding')
        path = self.cache_dir / "des_tensor.pt"
        if os.path.exists(path):
            return torch.load(path, map_location='cpu').to(self.device)

        descriptions = self.Des_Preprocess()

        # Use distilroberta-base for speed
        use_mps = torch.backends.mps.is_available()
        if use_mps:
            feature_extraction = pipeline(
                task='feature-extraction',
                model='distilroberta-base',
                tokenizer='distilroberta-base',
                device_map="auto",
                torch_dtype="auto",
                padding=True, truncation=True, max_length=500, add_special_tokens=True
            )
        else:
            dev = 0 if torch.cuda.is_available() else -1
            feature_extraction = pipeline(
                task='feature-extraction',
                model='distilroberta-base',
                tokenizer='distilroberta-base',
                device=dev,
                padding=True, truncation=True, max_length=500, add_special_tokens=True
            )

        H = 768
        vecs = []
        for text in tqdm(descriptions):
            if not text:
                vecs.append(torch.zeros(H))
                continue
            out = feature_extraction(str(text))
            t = torch.tensor(out)
            if t.ndim == 3:
                t = t[0]
            vecs.append(t.mean(dim=0))

        des_tensor = torch.stack(vecs, dim=0).to(self.device)
        torch.save(des_tensor, path)
        print('Finished')
        return des_tensor

    def tweets_preprocess(self):
        print('Loading raw feature2...', end='   ')
        path = self.cache_dir / "tweets.npy"
        if not os.path.exists('./processed_data_benchmark'):
            os.makedirs('./processed_data_benchmark', exist_ok=True)

        if not os.path.exists(path):
            # group all tweet_text for each user
            g = (
                self.df[["user_id", "tweet_text"]]
                .dropna(subset=["user_id"])
                .assign(tweet_text=lambda d: d["tweet_text"].fillna("").astype(str))
                .groupby("user_id")["tweet_text"]
                .apply(list)
            )
            limit = self.max_tweets_per_user  # 20
            tweets = [(g.get(uid, [""]) or [""])[:limit] for uid in self.user_ids_ordered]
            np.save(path, np.array(tweets, dtype=object))
        else:
            tweets = np.load(path, allow_pickle=True)
        print('Finished')
        return tweets

    def tweets_embedding(self):
        print('Running feature2 embedding')
        path = self.cache_dir / "tweets_tensor.pt"
        if os.path.exists(path):
            return torch.load(path, map_location='cpu').to(self.device)

        tweets_per_user = self.tweets_preprocess()

        use_mps = torch.backends.mps.is_available()
        if use_mps:
            feature_extract = pipeline(
                task='feature-extraction',
                model='roberta-base',
                tokenizer='roberta-base',
                device_map="auto",
                torch_dtype="auto",
                padding=True, truncation=True, max_length=500, add_special_tokens=True
            )
        else:
            dev = 0 if torch.cuda.is_available() else -1
            feature_extract = pipeline(
                task='feature-extraction',
                model='roberta-base',
                tokenizer='roberta-base',
                device=dev,
                padding=True, truncation=True, max_length=500, add_special_tokens=True
            )

        H = 768
        user_vecs = []
        for tws in tqdm(tweets_per_user):
            if not tws or (len(tws) == 1 and not tws[0]):
                user_vecs.append(torch.zeros(H))
                continue
            s = None
            c = 0
            for tw in tws:
                if not tw:
                    continue
                out = feature_extract(str(tw))
                t = torch.tensor(out)
                if t.ndim == 3:
                    t = t[0]
                v = t.mean(dim=0)
                s = v if s is None else (s + v)
                c += 1
            user_vecs.append((s / max(c, 1)) if s is not None else torch.zeros(H))

        tweets_tensor = torch.stack(user_vecs, dim=0).to(self.device)
        torch.save(tweets_tensor, path)
        print('Finished')
        return tweets_tensor

    def num_prop_preprocess(self):
        print('Processing feature3...', end='   ')
        path = self.cache_dir / "num_properties_tensor.pt"
        if os.path.exists(path):
            return torch.load(path, map_location='cpu').to(self.device)

        def nz(col, default=0):
            vals = self.user_tbl.get(
                col, pd.Series([default] * len(self.user_tbl), index=self.user_tbl.index)
            ).fillna(default).astype(float).values
            # Cap extreme outliers at 99th percentile for robustness
            p99 = np.percentile(vals, 99)
            vals = np.clip(vals, 0, p99)
            return vals

        # Apply log1p transformation for highly skewed features
        followers = torch.tensor(np.log1p(nz("user_followers_count")), dtype=torch.float32)
        friends   = torch.tensor(np.log1p(nz("user_following_count")), dtype=torch.float32)
        statuses  = torch.tensor(np.log1p(nz("user_tweets_count")),   dtype=torch.float32)
        favs      = torch.tensor(np.log1p(nz("tweets_like_count")),   dtype=torch.float32)
        listed    = torch.tensor(np.log1p(nz("user_listed_count")),   dtype=torch.float32)

        # active_days from user_created_at (fallback to 0)
        base = dt.strptime("Tue Sep 1 00:00:00 +0000 2020", "%a %b %d %X %z %Y")
        active_days = []
        for val in self.user_tbl.get("user_created_at", pd.Series([""] * len(self.user_tbl))):
            try:
                if pd.notna(val) and str(val):
                    d = pd.to_datetime(val)
                    if d.tzinfo is None:
                        d = d.tz_localize(base.tzinfo)
                    active_days.append(max((base - d).days, 0))
                else:
                    active_days.append(0)
            except Exception:
                active_days.append(0)
        active_days = torch.tensor(active_days, dtype=torch.float32)

        # screen_name length (also apply log1p)
        screen_len_raw = self.user_tbl.get("user_username", pd.Series([""] * len(self.user_tbl))).fillna("").map(len).values
        screen_len = torch.tensor(np.log1p(screen_len_raw), dtype=torch.float32)

        # Note: We'll apply RobustScaler in train.py, so just stack raw log-transformed features
        feats = torch.stack([
            followers, friends, favs, statuses, screen_len, active_days
        ], dim=1).to(self.device)

        torch.save(feats, path)
        print('Finished')
        return feats

    def cat_prop_preprocess(self):
        print('Processing feature4...', end='   ')
        path = self.cache_dir / "cat_properties_tensor.pt"
        if os.path.exists(path):
            return torch.load(path, map_location='cpu').to(self.device)

        # Enhanced categorical features matching BOTRGCN_Original architecture
        # Properties: verified, protected, geo_enabled, default_profile, etc.
        n_users = len(self.user_tbl)

        # 1. Verified status (from benchmark data)
        verified = (
            self.user_tbl.get("user_verified", pd.Series([False] * n_users))
            .fillna(False).astype(bool).astype(int).values
        )

        # 2. Has profile image (inferred from username != default pattern)
        has_profile_img = np.ones(n_users, dtype=int)  # Assume most have custom profiles

        # 3. Has pinned tweet
        has_pinned = (
            self.user_tbl.get("user_pinned_tweet_id", pd.Series([None] * n_users))
            .notna().astype(int).values
        )

        # 4. Has location/place info
        has_location = (
            self.user_tbl.get("user_place", pd.Series([None] * n_users))
            .notna().astype(int).values
        )

        # 5. Recent activity (tweets in last period - inferred from tweet count vs account age)
        followers = pd.to_numeric(self.user_tbl.get("user_followers_count", 0), errors='coerce').fillna(0)
        following = pd.to_numeric(self.user_tbl.get("user_following_count", 0), errors='coerce').fillna(0)
        active_ratio = np.where(followers + following > 100, 1, 0)  # Has substantial network

        # Additional features to reach 11 dimensions (matching original)
        zeros = np.zeros(n_users, dtype=int)

        # Stack all categorical features [11 features total]
        cats = np.stack([
            verified,           # 0: verified account
            has_profile_img,    # 1: has custom profile image
            has_pinned,         # 2: has pinned tweet
            has_location,       # 3: has location info
            active_ratio,       # 4: active engagement ratio
            zeros,              # 5: placeholder
            zeros,              # 6: placeholder
            zeros,              # 7: placeholder
            zeros,              # 8: placeholder
            zeros,              # 9: placeholder
            zeros               # 10: placeholder
        ], axis=1)

        cats = torch.tensor(cats, dtype=torch.float32).to(self.device)
        torch.save(cats, path)
        print('Finished')
        return cats

    def Build_Graph(self):
        # edge_index: [2, E], edge_type: [E] with
        # {mentioned:0, replied_to:1, co_mention:2, co_reply:3, same_conversation:4}
        return self.edge_index.to(self.device), self.edge_type.to(self.device)

    def train_val_test_mask(self):
        train_idx, val_idx, test_idx = self._build_split_masks_from_csv()

        # It’s OK if train/val are empty for inference.
        # Only require test to have at least 1 user; otherwise create a full "test" mask.
        if int(test_idx.sum().item()) == 0:
            N = len(self.user_ids_ordered)
            test_idx = torch.ones(N, dtype=torch.bool)

        return train_idx.to(self.device), val_idx.to(self.device), test_idx.to(self.device)

    def get_all_tensors(self):
        """
        Return tensors in the exact order expected by test/inference code:
        (des, tweet, num_prop, cat_prop, edge_index, edge_type, labels, train_mask, val_mask, test_mask)
        """
        labels        = self.load_labels()
        des_tensor    = (self.Des_embbeding() if self.include_text_features
                         else torch.zeros((len(self.user_ids_ordered), 768), device=self.device))
        tweets_tensor = (self.tweets_embedding() if self.include_text_features
                         else torch.zeros((len(self.user_ids_ordered), 768), device=self.device))
        num_prop      = self.num_prop_preprocess()
        cat_prop      = self.cat_prop_preprocess()
        edge_index, edge_type = self.Build_Graph()
        train_idx, val_idx, test_idx = self.train_val_test_mask()

        # Sanity checks
        N = len(self.user_ids_ordered)
        assert des_tensor.shape[0]    == N, ("descriptions bad len", des_tensor.shape, N)
        assert tweets_tensor.shape[0] == N, ("tweets bad len", tweets_tensor.shape, N)
        assert num_prop.shape[0]      == N, ("num_prop bad len", num_prop.shape, N)
        assert cat_prop.shape[0]      == N, ("cat_prop bad len", cat_prop.shape, N)
        assert labels.shape[0]        == N, ("labels bad len", labels.shape, N)

        return (des_tensor, tweets_tensor, num_prop, cat_prop,
                edge_index, edge_type, labels, train_idx, val_idx, test_idx)

    def dataloader(self):
        """
        Legacy compat wrapper; identical outputs to get_all_tensors(),
        with additional split summaries printed.
        """
        labels        = self.load_labels()
        des_tensor    = (self.Des_embbeding() if self.include_text_features
                         else torch.zeros((len(self.user_ids_ordered), 768), device=self.device))
        tweets_tensor = (self.tweets_embedding() if self.include_text_features
                         else torch.zeros((len(self.user_ids_ordered), 768), device=self.device))
        num_prop      = self.num_prop_preprocess()
        cat_prop      = self.cat_prop_preprocess()
        edge_index, edge_type = self.Build_Graph()
        train_idx, val_idx, test_idx = self.train_val_test_mask()

        N = len(self.user_ids_ordered)
        assert des_tensor.shape[0]    == N, ("descriptions bad len", des_tensor.shape, N)
        assert tweets_tensor.shape[0] == N, ("tweets bad len", tweets_tensor.shape, N)
        assert num_prop.shape[0]      == N, ("num_prop bad len", num_prop.shape, N)
        assert cat_prop.shape[0]      == N, ("cat_prop bad len", cat_prop.shape, N)
        assert labels.shape[0]        == N, ("labels bad len", labels.shape, N)

        for name, m in [("train", train_idx), ("val", val_idx), ("test", test_idx)]:
            n = int(m.sum().item())
            b = int(labels[m].sum().item())
            print(f"[split={name}] users={n}  bots={b}  bot_rate={b/max(n,1):.3f}")

        return (des_tensor, tweets_tensor, num_prop, cat_prop,
                edge_index, edge_type, labels, train_idx, val_idx, test_idx)
