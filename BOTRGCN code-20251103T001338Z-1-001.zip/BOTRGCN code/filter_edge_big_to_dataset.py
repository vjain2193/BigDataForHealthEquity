#!/usr/bin/env python3
# filter_edge_big_to_dataset.py
import argparse
import json
import time
from collections import defaultdict
from datetime import datetime
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd


# --------------------------
# Helpers
# --------------------------
def norm_id(x) -> str:
    s = str(x).strip()
    if s.startswith("u"):
        s = s[1:]
    if s.endswith(".0"):
        s = s[:-2]
    return s


def _parse_list_field(val):
    """
    Robust list parser that tolerates JSON strings, Python-like lists, and dict-style Twitter entities.
    Returns a list of strings.
    """
    if isinstance(val, list):
        return [str(v) for v in val]
    s = str(val).strip()
    if not s or s.lower() == "nan" or s == "[]":
        return []
    try:
        v = json.loads(s)
        if isinstance(v, list):
            return [str(z) for z in v]
        if isinstance(v, dict):
            ms = v.get("mentions") or v.get("user_mentions") or []
            out = []
            for m in ms:
                if isinstance(m, dict):
                    out.append(
                        str(
                            m.get("id")
                            or m.get("id_str")
                            or m.get("user_id")
                            or m.get("screen_name")
                            or ""
                        )
                    )
            return [x for x in out if x]
    except Exception:
        pass
    # lax fallback for strings like "['a','b']"
    s = s.strip("[]")
    if not s:
        return []
    return [t.strip().strip("'").strip('"') for t in s.split(",") if t.strip()]


def add_pairs_from_bucket(authors, rel, out_edges, max_pairs=20000):
    """
    authors: iterable of user_ids (string) in a bucket.
    Adds undirected pairs (both directions) up to max_pairs *directed* edges per bucket.
    """
    uniq = sorted(set(a for a in authors if a))
    k = len(uniq)
    if k < 2:
        return
    comb = list(combinations(range(k), 2))
    # cap
    if len(comb) * 2 > max_pairs:
        sel = np.random.choice(len(comb), size=max_pairs // 2, replace=False)
        comb = [comb[i] for i in sel]
    for i, j in comb:
        a, b = uniq[i], uniq[j]
        if a != b:
            out_edges.append((a, rel, b))
            out_edges.append((b, rel, a))


# --------------------------
# Core builder
# --------------------------
def build_edges_for_csv(
    csv_path: Path,
    out_dir: Path,
    max_pairs_per_bucket: int = 20000,
    max_pairs_per_tweet: int = 200,  # for co_mention-within-tweet
) -> Path:
    """
    Build edges for a single CSV and write to out_dir/edge.csv.
    Returns the edge.csv path.
    """
    t0 = time.time()
    stem = csv_path.stem
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "edge.csv"

    print("\n" + "=" * 80)
    print(f"BUILDING EDGES FOR {csv_path.name} - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)
    print(f"Input file:  {csv_path}")
    print(f"Output file: {out_path}")

    file_size_gb = csv_path.stat().st_size / (1024 ** 3)
    print(f"Input file size: {file_size_gb:.2f} GB")

    # Load
    print("\nLoading data...")
    t_load = time.time()
    if file_size_gb > 2.0:
        print("Large file detected; using chunked loading (100k rows/chunk)...")
        chunks = []
        for i, chunk in enumerate(pd.read_csv(csv_path, low_memory=False, chunksize=100_000)):
            chunks.append(chunk)
            if (i + 1) % 20 == 0:
                print(f"  Loaded {(i + 1) * 100_000:,} rows...")
        df = pd.concat(chunks, ignore_index=True)
    else:
        df = pd.read_csv(csv_path, low_memory=False)
    print(f"Data loaded in {time.time() - t_load:.2f}s  •  rows={len(df):,}")

    # Universe of users (normalize)
    users = set(df["user_id"].astype(str).map(norm_id).tolist())
    print(f"Unique users in dataset: {len(users):,}")

    # Column names (best-effort)
    mention_id_col = "entities_tweet_mention_id"
    mention_un_col = "entities_tweet_mention_username"
    reply_col = "tweets_in_reply_to_user_id"
    conv_col = "conversation_id"
    tweet_id_col = "tweet_id" if "tweet_id" in df.columns else None

    # Normalize per-row
    df["author"] = df["user_id"].astype(str).map(norm_id)

    # Mentions: parse both ids + usernames
    df["mentions_ids"] = df[mention_id_col].map(_parse_list_field) if mention_id_col in df.columns else [[] for _ in range(len(df))]
    df["mentions_un"] = (
        df[mention_un_col].map(_parse_list_field).map(lambda xs: [str(x).lower() for x in xs])
        if mention_un_col in df.columns
        else [[] for _ in range(len(df))]
    )

    # Reply-to
    if reply_col in df.columns:
        df["reply_to"] = df[reply_col].map(lambda x: norm_id(x) if pd.notna(x) and str(x).strip() else "")
    else:
        df["reply_to"] = ""

    # Conversation id
    if conv_col in df.columns:
        df["conv"] = df[conv_col].map(lambda x: str(x).strip() if pd.notna(x) and str(x).strip().lower() != "nan" else "")
    else:
        df["conv"] = ""

    # Optional tweet id (for co_mention within a tweet)
    if tweet_id_col:
        df["tweet_id_norm"] = df[tweet_id_col].astype(str).str.strip()
    else:
        df["tweet_id_norm"] = ""

    # Username -> user_id map (from your own CSV)
    name2id = (
        df[["user_username", "user_id"]]
        .dropna()
        .assign(
            user_username=lambda d: d["user_username"].astype(str).str.strip().str.lower(),
            user_id=lambda d: d["user_id"].astype(str).map(norm_id),
        )
        .drop_duplicates(subset=["user_username"])
        .set_index("user_username")["user_id"]
        .to_dict()
    )

    # --------------------------
    # DIRECT edges (author -> mentioned, author -> replied_to)
    # --------------------------
    edges = []
    direct_mention = 0
    direct_reply = 0

    for au, mids, muns, rp in zip(df["author"], df["mentions_ids"], df["mentions_un"], df["reply_to"]):
        if au not in users:
            continue

        # targets from mention IDs
        ids_from_id = [norm_id(x) for x in mids if x]
        # targets from usernames (mapped to IDs if we know them)
        ids_from_un = [name2id[u] for u in muns if u in name2id]

        targets = list({z for z in (ids_from_id + ids_from_un) if z in users and z != au})
        for v in targets:
            edges.append((au, "mentioned", v))
            direct_mention += 1

        if rp and rp in users and rp != au:
            edges.append((au, "replied_to", rp))
            direct_reply += 1

    # --------------------------
    # PROJECTED edges (density)
    #   • co_mention (WITHIN a tweet): pair among mentioned targets in the same tweet
    #   • co_reply: authors replying to the same target
    #   • same_conversation: authors in the same conversation
    # --------------------------
    # co_mention within tweet
    co_m_within_cnt = 0
    if tweet_id_col:
        for tw_mids, tw_muns in zip(df["mentions_ids"], df["mentions_un"]):
            # build target list for this tweet (IDs + mapped usernames), keep only in users
            t_ids = [norm_id(x) for x in tw_mids if x]
            t_ids += [name2id[u] for u in tw_muns if u in name2id]
            tgt = sorted({z for z in t_ids if z in users})
            if len(tgt) < 2:
                continue
            comb = list(combinations(range(len(tgt)), 2))
            # cap
            if len(comb) * 2 > max_pairs_per_tweet:
                sel = np.random.choice(len(comb), size=max_pairs_per_tweet // 2, replace=False)
                comb = [comb[i] for i in sel]
            before = len(edges)
            for i, j in comb:
                a, b = tgt[i], tgt[j]
                if a != b:
                    edges.append((a, "co_mention", b))
                    edges.append((b, "co_mention", a))
            co_m_within_cnt += (len(edges) - before)

    # co_reply: authors who reply to the same target (even if the target is outside users)
    buckets_reply = defaultdict(list)
    for au, rp in zip(df["author"], df["reply_to"]):
        if au in users and rp:
            buckets_reply[rp].append(au)

    co_reply_cnt = 0
    for _, authors in buckets_reply.items():
        before = len(edges)
        add_pairs_from_bucket(authors, "co_reply", edges, max_pairs=max_pairs_per_bucket)
        co_reply_cnt += (len(edges) - before)

    # same_conversation: authors in the same conversation id
    buckets_conv = defaultdict(list)
    for au, cv in zip(df["author"], df["conv"]):
        if au in users and cv:
            buckets_conv[cv].append(au)

    same_conv_cnt = 0
    for _, authors in buckets_conv.items():
        before = len(edges)
        add_pairs_from_bucket(authors, "same_conversation", edges, max_pairs=max_pairs_per_bucket)
        same_conv_cnt += (len(edges) - before)

    # --------------------------
    # Finalize
    # --------------------------
    df_edges = pd.DataFrame(edges, columns=["source_id", "relation", "target_id"])

    # Filter to in-universe endpoints & drop self-loops / dupes
    df_edges = df_edges[(df_edges["source_id"].isin(users)) & (df_edges["target_id"].isin(users))]
    df_edges = df_edges[df_edges["source_id"] != df_edges["target_id"]].drop_duplicates()

    counts = df_edges["relation"].value_counts().to_dict()
    print(
        f"Direct edges:    mentioned={direct_mention:,}  replied_to={direct_reply:,}\n"
        f"Projected edges: co_mention(within_tweet)={co_m_within_cnt:,}  "
        f"co_reply={co_reply_cnt:,}  same_conversation={same_conv_cnt:,}\n"
        f"Final edge counts: {counts}   total={len(df_edges):,}"
    )

    df_edges.to_csv(out_path, index=False)
    print(f"Wrote → {out_path}  (elapsed {time.time() - t0:.2f}s)")
    return out_path


# --------------------------
# CLI
# --------------------------
def main():
    ap = argparse.ArgumentParser(description="Build 5-relation edge.csv from a benchmark-style CSV")
    ap.add_argument("--root", help="Folder containing Benchmark_data_10k.csv / 100k / 1M (batch mode)")
    ap.add_argument("--csv", help="Path to a single CSV (single-file mode)")
    ap.add_argument("--output", help="Output directory (defaults to CSV's directory or processed_data_benchmark/<stem> in batch mode)")
    ap.add_argument("--max-pairs-bucket", type=int, default=20000, help="Cap on directed edges generated per bucket (co_reply/same_conversation)")
    ap.add_argument("--max-pairs-tweet", type=int, default=200, help="Cap on directed co_mention edges generated per tweet")

    args = ap.parse_args()

    if args.csv:
        csv_path = Path(args.csv)
        if not csv_path.exists():
            print(f"Error: CSV file not found: {csv_path}")
            return
        # Align output directory with preprocess pipeline structure
        if args.output:
            out_dir = Path(args.output)
        else:
            # Default: save to processed_data_benchmark/<csv_stem> to match preprocess_1/2
            out_dir = Path("processed_data_benchmark") / csv_path.stem
        edge_path = build_edges_for_csv(
            csv_path, out_dir,
            max_pairs_per_bucket=args.max_pairs_bucket,
            max_pairs_per_tweet=args.max_pairs_tweet,
        )
        print("\nNext step:")
        print(f"python test_data.py --csv {csv_path} --edges {edge_path}")

    elif args.root:
        root = Path(args.root)
        candidates = []
        for name in ["Benchmark_data_10k.csv", "Benchmark_data_100k.csv", "Benchmark_data_1m.csv", "Benchmark_data_1M.csv"]:
            p = root / name
            if p.exists():
                candidates.append(p)
        if not candidates:
            print(f"No benchmark CSVs found under {root}")
            return
        for csv_path in candidates:
            out_dir = Path("processed_data_benchmark") / csv_path.stem
            build_edges_for_csv(
                csv_path, out_dir,
                max_pairs_per_bucket=args.max_pairs_bucket,
                max_pairs_per_tweet=args.max_pairs_tweet,
            )
    else:
        print("Error: provide either --csv or --root.")
        print("\nExamples:")
        print("  Single file:  python filter_edge_big_to_dataset.py --csv Unseen_data_testing_with_split_1m.csv")
        print("  Batch mode:   python filter_edge_big_to_dataset.py --root /path/to/folder/with/Benchmark_csvs")


if __name__ == "__main__":
    main()
