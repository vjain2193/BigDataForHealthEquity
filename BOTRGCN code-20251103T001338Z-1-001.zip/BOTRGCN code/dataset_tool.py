# dataset_tool.py
from pathlib import Path
import os
import re
import json
import shutil

import numpy as np
import pandas as pd
import torch
from tqdm import tqdm
from transformers import RobertaTokenizer, RobertaModel

# ----------------------------- Cache helpers -----------------------------

CACHE_ROOT = Path("./processed_cache")  # change if you want
CACHE_ROOT.mkdir(parents=True, exist_ok=True)

def clear_cache(dataset: str):
    shutil.rmtree(_cache_dir(dataset), ignore_errors=True)

def _cache_dir(dataset: str) -> Path:
    d = CACHE_ROOT / str(dataset)
    d.mkdir(parents=True, exist_ok=True)
    return d

# ----------------------------- Normalization -----------------------------

# Known Benchmark-style datasets (normalized to lowercase)
BENCHMARK_DATASETS_NORM = {
    "benchmark_data_10k",
    "benchmark_data_100k",
    "benchmark_data_1m",
    "unseen_data_testing_with_split",       # generic unseen
    "unseen_data_testing_with_split_1m",    # your 1M variant
}

def _norm_split(s: str) -> str:
    if not isinstance(s, str):
        return ""
    s = s.strip().lower()
    return {
        "validation": "val",
        "valid": "val",
        "testing": "test",
        "trainning": "train",
    }.get(s, s)

def _label_to_int(v) -> int:
    s = str(v).strip().lower()
    if s in ("1", "bot", "true", "yes"):
        return 1
    return 0

def _norm_dataset_token(raw: str) -> tuple[str, str]:
    """
    Returns (normalized_token, csv_filename).
    Accepts 'Benchmark_data_10k', 'Benchmark_data_10k.csv', paths, etc.
    """
    stem = Path(str(raw)).stem  # remove any .csv
    norm = stem.strip().lower()
    return norm, f"{stem}.csv"

# ----------------------------- TwiBot-22 builder -----------------------------

def build_node_df_twibot22(base: Path) -> pd.DataFrame:
    """
    Build a 'node' dataframe from TwiBot-22 parts (no node.json in release).
    Returns a DataFrame where user rows and tweet rows are stacked together.
    Only includes columns your later code relies on.
    Folder should contain:
      - user.json (JSONL)
      - tweet_*.json (JSONL shards)
      - label.csv (id -> label)
      - split.csv (id -> split)
    """
    # ---- users ----
    u_path = base / "user.json"
    if not u_path.exists():
        raise FileNotFoundError(f"Missing TwiBot-22 file: {u_path}")
    users = pd.read_json(u_path, lines=True)

    profile_col = users["profile"] if "profile" in users.columns else pd.Series([{}] * len(users))
    pm_col      = users["public_metrics"] if "public_metrics" in users.columns else pd.Series([{}] * len(users))
    verified    = users["verified"] if "verified" in users.columns else pd.Series([False] * len(users))

    def _u(pm, k, default=0):
        return (pm or {}).get(k, default)

    u = pd.DataFrame({
        "id":                   users["id"].astype(str).map(lambda x: f"u{x}"),
        "type":                 "user",
        "user_id":              users["id"].astype(str),
        "user_profile":         profile_col.apply(lambda x: (x or {}).get("description", "")),
        "user_username":        profile_col.apply(lambda x: (x or {}).get("screen_name", "")),
        "user_created_at":      profile_col.apply(lambda x: (x or {}).get("created_at", "")),
        "user_verified":        verified.fillna(False).astype(bool),
        "user_followers_count": pm_col.apply(lambda pm: _u(pm, "followers_count")),
        "user_following_count": pm_col.apply(lambda pm: _u(pm, "following_count")),
        "user_tweets_count":    pm_col.apply(lambda pm: _u(pm, "tweet_count")),
        "user_listed_count":    pm_col.apply(lambda pm: _u(pm, "listed_count")),
    })

    # ---- tweets (merge all shards) ----
    tweet_files = sorted(base.glob("tweet_*.json"))
    if len(tweet_files) == 0:
        raise FileNotFoundError(f"No tweet_*.json files found under {base}")

    tweets = pd.concat([pd.read_json(p, lines=True) for p in tweet_files], ignore_index=True)

    def _mentions(ent):
        ent = ent or {}
        ms = ent.get("mentions", []) or ent.get("user_mentions", [])
        out = []
        for m in ms:
            val = m.get("id") or m.get("id_str") or m.get("user_id") or m.get("screen_name")
            if val is not None:
                out.append(str(val))
        return out

    if "author_id" in tweets.columns:
        author = tweets["author_id"].astype(str)
    elif "user_id" in tweets.columns:
        author = tweets["user_id"].astype(str)
    else:
        author = pd.Series([""] * len(tweets))

    t = pd.DataFrame({
        "id":                         tweets["id"].astype(str).map(lambda x: f"t{x}"),
        "type":                       "tweet",
        "tweet_id":                   tweets["id"].astype(str),
        "user_id":                    author,
        "tweet_text":                 tweets.get("text", pd.Series([""] * len(tweets))).fillna(""),
        "tweet_timestamp":            tweets.get("created_at", pd.Series([""] * len(tweets))),
        "entities_tweet_mention_id":  tweets.get("entities", pd.Series([{}] * len(tweets))).apply(_mentions),
        "tweets_in_reply_to_user_id": tweets.get("in_reply_to_user_id", pd.Series([None] * len(tweets))),
    })

    node_df = pd.concat([u, t], ignore_index=True)

    # attach labels/splits (users only)
    label_path = base / "label.csv"
    split_path = base / "split.csv"
    if not label_path.exists() or not split_path.exists():
        raise FileNotFoundError(f"Missing label/split CSVs in {base}")

    label = pd.read_csv(label_path)  # id (u...), label
    split = pd.read_csv(split_path)  # id (u...), split
    node_df = node_df.merge(label, how="left", on="id")
    node_df = node_df.merge(split,  how="left", on="id")
    return node_df

# ----------------------------- Data dir resolution -----------------------------

def get_data_dir(server_id: str = "209") -> Path:
    """
    Base folder that contains your Benchmark CSVs.
    1) Set env BOTRG_DATA_DIR to override
    2) Otherwise, default to your local path
    """
    env = os.environ.get("BOTRG_DATA_DIR")
    if env:
        return Path(env).expanduser().resolve()

    # <-- EDIT THIS TO MATCH THE FOLDER THAT HOLDS YOUR CSVs -->
    # If your CSVs live in ".../User_based_split", point here.
    return Path("/Users/bala/Documents/RA/Bot Analytics/My_twibot_22_based_on_Original_2").resolve()

# ----------------------------- Merge & split -----------------------------

def merge(dataset: str = "Benchmark_data_10k", server_id: str = "209"):
    """
    Unifies dataset resolution:

    - If `dataset` is a literal CSV file path, read and return it as a DataFrame.
    - If `dataset` is a Benchmark-like token (e.g., 'Benchmark_data_1m'),
      resolve CSV in get_data_dir(...), load and return it.
    - Otherwise fall back to legacy TwiBot-22 folder layout and build a node table.

    For CSV paths / Benchmark tokens:
      * Ensures 'split' (if present) is normalized to {'train','val','test'}
      * Ensures id fields and 'label' are string-typed where present
    """
    # --- 1) literal CSV path ---
    p = Path(dataset)
    if p.exists() and p.is_file() and p.suffix.lower() == ".csv":
        df = pd.read_csv(p, low_memory=False)
        if "split" not in df.columns:
            df["split"] = "test"
        # normalize
        df["split"] = df["split"].apply(_norm_split)
        for c in ("user_id", "tweet_id", "label"):
            if c in df.columns:
                df[c] = df[c].astype(str)
        return df

    # --- 2) Benchmark token resolution ---
    ds_norm, guessed_csv_name = _norm_dataset_token(dataset)
    base = get_data_dir(server_id)

    if ds_norm in BENCHMARK_DATASETS_NORM:
        candidates = [
            base / guessed_csv_name,                          # Benchmark_data_1m.csv
            base / guessed_csv_name.replace("1m.csv", "1M.csv"),
            base / ds_norm / guessed_csv_name,               # <token>/<token>.csv
            base / ds_norm / "nodes.csv",                    # <token>/nodes.csv
        ]
        csv_path = next((pp for pp in candidates if pp.exists()), None)
        if csv_path is None:
            raise FileNotFoundError(
                f"Could not find CSV for {dataset}. Tried: "
                + ", ".join(str(pp) for pp in candidates)
                + f" (BOTRG_DATA_DIR={base})"
            )

        # Optional cache directory (not strictly needed here)
        cache_dir = base / Path(guessed_csv_name).stem / "_cache"
        cache_dir.mkdir(parents=True, exist_ok=True)

        df = pd.read_csv(csv_path, low_memory=False)

        if "split" in df.columns:
            df["split"] = df["split"].apply(_norm_split)

        for c in ("user_id", "tweet_id", "label"):
            if c in df.columns and df[c].dtype != object:
                df[c] = df[c].astype(str)

        return df

    # --- 3) Legacy TwiBot-22 folder layout ---
    dataset_dir = base / dataset
    if not dataset_dir.exists():
        raise FileNotFoundError(f"Unknown dataset '{dataset}' at {dataset_dir}")

    node_info = build_node_df_twibot22(dataset_dir)
    return node_info

def split_user_and_tweet(df: pd.DataFrame):
    """
    Split user and tweet from df (legacy), and ignore entries whose id is `None`.
    """
    df = df[df.id.str.len() > 0]
    return df[df.id.str.contains("^u")], df[df.id.str.contains("^t")]

def fast_merge(dataset="Twibot-20", server_id="209"):
    """
    Legacy helper for TwiBot-style folders only.
    For Benchmark_* CSVs we simply return (None, None).
    """
    ds_norm, _ = _norm_dataset_token(dataset)
    if ds_norm in BENCHMARK_DATASETS_NORM:
        print(f"fast_merge not applicable for {dataset} (Benchmark CSV).")
        return None, None

    dataset_dir = get_data_dir(server_id) / dataset
    if not dataset_dir.exists():
        raise FileNotFoundError(f"Unknown dataset '{dataset}' at {dataset_dir}")

    node_info = pd.read_json(dataset_dir / "node.json")
    label     = pd.read_csv(dataset_dir / "label.csv")
    split     = pd.read_csv(dataset_dir / "split.csv")

    user, tweet = split_user_and_tweet(node_info)

    id_to_label = dict(zip(label["id"],  label["label"]))
    id_to_split = dict(zip(split["id"],  split["split"]))

    user = user.copy()
    user["label"] = user["id"].map(id_to_label).fillna("None")
    user["split"] = user["id"].map(id_to_split).fillna("None")
    return user, tweet

def merge_and_split(dataset="Benchmark_data_10k", server_id="209"):
    """
    Return (train_df, val_df, test_df).
    Supports Benchmark_* CSVs and falls back to TwiBot-style folders otherwise.
    """
    ds_norm, _ = _norm_dataset_token(dataset)

    # --- Benchmark CSV path ---
    if ds_norm in BENCHMARK_DATASETS_NORM or (
        Path(dataset).suffix.lower() == ".csv" and Path(dataset).exists()
    ):
        df = merge(dataset, server_id)
        return (
            df[df["split"].eq("train")].copy(),
            df[df["split"].eq("val")].copy(),
            df[df["split"].eq("test")].copy(),
        )

    # --- Legacy TwiBot path ---
    dataset_dir = get_data_dir(server_id) / dataset
    if not dataset_dir.exists():
        raise FileNotFoundError(f"Unknown dataset '{dataset}' at {dataset_dir}")

    node_info = pd.read_json(dataset_dir / "node.json")
    label     = pd.read_csv(dataset_dir / "label.csv")
    split     = pd.read_csv(dataset_dir / "split.csv")

    node_info = pd.merge(node_info, label)
    node_info = pd.merge(node_info, split)

    train = node_info[node_info["split"] == "train"].copy()
    valid = node_info[node_info["split"] == "val"].copy()
    test  = node_info[node_info["split"] == "test"].copy()
    return train, valid, test

# ----------------------------- Simple vectorizers -----------------------------

@torch.no_grad()
def simple_vectorize(data: pd.DataFrame):
    """
    Embeds user descriptions with roberta-base and returns (features, labels).
    Expects columns:
      - user_profile or description
      - label (string/bool/int)
    """
    tokenizer = RobertaTokenizer.from_pretrained('roberta-base')
    model = RobertaModel.from_pretrained('roberta-base')

    descriptions = list(
        data.get("user_profile", data.get("description", pd.Series([""]*len(data))))
        .fillna("")
        .values
    )
    labels = data["label"].apply(_label_to_int).astype(int).values

    feats = []
    for text in tqdm(descriptions, desc="Embedding descriptions"):
        if not text:
            feats.append(torch.zeros(768))
            continue
        enc = tokenizer(str(text), return_tensors='pt', truncation=True, max_length=512)
        out = model(**enc)
        vec = out.last_hidden_state.mean(dim=1).squeeze(0)  # mean pool
        feats.append(vec.detach().cpu())
    feats = torch.stack(feats, dim=0)

    return feats.numpy(), labels.astype(np.int32)

# ----------------------------- Graph builders -----------------------------

@torch.no_grad()
def hetero_graph_vectorize(
    include_node_feature: bool = False,
    dataset: str = "Benchmark_data_10k",
    server_id: str = "209",
):
    """
    Build a HeteroData graph with nodes {user, tweet} and edges:
      - (user)-[post]->(tweet)
      - (user)-[mention]->(user)
      - (user)-[reply]->(user)
    using only columns available in your Benchmark CSVs (or literal CSV).
    """
    from torch_geometric.data import HeteroData

    df = merge(dataset, server_id)
    if df is None or df.empty:
        raise RuntimeError(f"No data for dataset {dataset}")

    # Normalize/clean a few fields we rely on
    if "user_id" not in df.columns or "tweet_id" not in df.columns:
        raise KeyError("Expected 'user_id' and 'tweet_id' columns in the dataset.")
    df["user_id"] = df["user_id"].astype(str)
    df["tweet_id"] = df["tweet_id"].astype(str)
    df["split"]   = df["split"].astype(str).str.strip().str.lower()

    # ---------- Build user / tweet indices ----------
    user_tbl = (df[["user_id", "label", "split"]]
                .dropna(subset=["user_id"])
                .drop_duplicates(subset=["user_id"], keep="first")
                .reset_index(drop=True))
    user_ids = user_tbl["user_id"].tolist()
    uid_to_user_index = {u: i for i, u in enumerate(user_ids)}

    tweet_ids = df["tweet_id"].dropna().astype(str).unique().tolist()
    tid_to_tweet_index = {t: i for i, t in enumerate(tweet_ids)}

    graph = HeteroData()
    graph["user"].num_nodes  = len(user_ids)
    graph["tweet"].num_nodes = len(tweet_ids)

    # (user) -post-> (tweet)
    post_src, post_dst = [], []
    # (user) -mention-> (user)
    men_src,  men_dst  = [], []
    # (user) -reply-> (user)
    rep_src,  rep_dst  = [], []

    def _parse_id_list(x):
        if pd.isna(x):
            return []
        if isinstance(x, list):
            return [str(v) for v in x]
        s = str(x).strip()
        if not s or s == "[]":
            return []
        try:
            v = json.loads(s)
            if isinstance(v, list):
                return [str(z) for z in v]
        except Exception:
            pass
        s = s.strip("[]")
        if not s:
            return []
        return [t.strip().strip("'").strip('"') for t in s.split(",") if t.strip()]

    for _, row in df.iterrows():
        u = uid_to_user_index.get(str(row["user_id"]), None)
        t = tid_to_tweet_index.get(str(row["tweet_id"]), None)
        if u is not None and t is not None:
            post_src.append(u); post_dst.append(t)

        for mid in _parse_id_list(row.get("entities_tweet_mention_id", None)):
            v = uid_to_user_index.get(str(mid), None)
            if u is not None and v is not None:
                men_src.append(u); men_dst.append(v)

        ruid = row.get("tweets_in_reply_to_user_id", None)
        if pd.notna(ruid):
            v = uid_to_user_index.get(str(ruid), None)
            if u is not None and v is not None:
                rep_src.append(u); rep_dst.append(v)

    def _to_edge(src, dst):
        if len(src) == 0:
            return torch.empty((2, 0), dtype=torch.long)
        return torch.tensor([src, dst], dtype=torch.long)

    graph["user", "post", "tweet"].edge_index    = _to_edge(post_src, post_dst)
    graph["user", "mention", "user"].edge_index  = _to_edge(men_src,  men_dst)
    graph["user", "reply",   "user"].edge_index  = _to_edge(rep_src,  rep_dst)

    # reverse edges (optional)
    if graph["user","post","tweet"].edge_index.numel() > 0:
        graph["tweet","posted_by","user"].edge_index = torch.flip(
            graph["user","post","tweet"].edge_index, dims=[0]
        )

    # ---------- Train/Val/Test user lists with labels ----------
    train_uid_with_label = user_tbl[user_tbl["split"] == "train"][["user_id", "split", "label"]].rename(columns={"user_id": "id"})
    valid_uid_with_label = user_tbl[user_tbl["split"] == "val"][["user_id", "split", "label"]].rename(columns={"user_id": "id"})
    test_uid_with_label  = user_tbl[user_tbl["split"] == "test"][["user_id", "split", "label"]].rename(columns={"user_id": "id"})

    # ---------- node features ----------
    if include_node_feature:
        tok = RobertaTokenizer.from_pretrained("roberta-base")
        mdl = RobertaModel.from_pretrained("roberta-base")

        # user feature (text)
        user_desc = (df[["user_id", "user_profile"]]
                     .drop_duplicates(subset=["user_id"], keep="first")
                     .set_index("user_id")
                     .reindex(user_ids)["user_profile"]
                     .fillna("").astype(str).tolist())

        def _embed_text_list(texts):
            vecs = []
            for txt in tqdm(texts, desc="Embedding"):
                if not txt:
                    vecs.append(torch.zeros(768))
                    continue
                enc = tok(str(txt), return_tensors="pt", truncation=True, max_length=512)
                out = mdl(**enc)
                h = out.last_hidden_state.mean(dim=1).squeeze(0)
                vecs.append(h.detach().cpu())
            return torch.stack(vecs, dim=0)

        graph["user"].x = _embed_text_list(user_desc)

        # tweet feature (text)
        tweet_text = (df[["tweet_id", "tweet_text"]]
                      .dropna(subset=["tweet_id"])
                      .drop_duplicates(subset=["tweet_id"], keep="first")
                      .set_index("tweet_id")
                      .reindex(tweet_ids)["tweet_text"]
                      .fillna("").astype(str).tolist())
        graph["tweet"].x = _embed_text_list(tweet_text)

    # ---------- Save cache ----------
    cdir = _cache_dir(dataset)
    torch.save(graph, cdir / "hetero_graph.pt")
    torch.save(uid_to_user_index,  cdir / "uid_to_user_index.pt")
    torch.save(tid_to_tweet_index, cdir / "tid_to_tweet_index.pt")

    # Return API compatible with earlier code
    return (
        graph,
        uid_to_user_index,
        tid_to_tweet_index,
        train_uid_with_label,
        valid_uid_with_label,
        test_uid_with_label,
        user_ids,
        tweet_ids,
    )

@torch.no_grad()
def homo_graph_vectorize_only_user(
    include_node_feature: bool = False,
    dataset: str = "Benchmark_data_10k",
    server_id: str = "209",
):
    """
    Build a homogeneous user graph with edges aggregated from:
      - mention: (author user) -> (mentioned user)
      - reply:   (author user) -> (replied-to user)
    """
    df = merge(dataset, server_id)
    if df is None or df.empty:
        raise RuntimeError(f"No data for dataset {dataset}")

    if "user_id" not in df.columns:
        raise KeyError("Expected 'user_id' column in the dataset.")

    df["user_id"] = df["user_id"].astype(str)
    df["split"]   = df["split"].astype(str).str.strip().str.lower()

    # user table (unique)
    user_tbl = (df[["user_id", "label", "split"]]
                .dropna(subset=["user_id"])
                .drop_duplicates(subset=["user_id"], keep="first")
                .reset_index(drop=True))
    user_ids = user_tbl["user_id"].tolist()
    uid_to_user_index = {u: i for i, u in enumerate(user_ids)}

    # parse edges
    def _parse_id_list(x):
        if pd.isna(x):
            return []
        if isinstance(x, list):
            return [str(v) for v in x]
        s = str(x).strip()
        if not s or s == "[]":
            return []
        try:
            v = json.loads(s)
            if isinstance(v, list):
                return [str(z) for z in v]
        except Exception:
            pass
        s = s.strip("[]")
        if not s:
            return []
        return [t.strip().strip("'").strip('"') for t in s.split(",") if t.strip()]

    men_src, men_dst = [], []
    rep_src, rep_dst = [], []

    for _, row in df.iterrows():
        u = uid_to_user_index.get(str(row["user_id"]))
        if u is None:
            continue

        for mid in _parse_id_list(row.get("entities_tweet_mention_id", None)):
            v = uid_to_user_index.get(str(mid))
            if v is not None:
                men_src.append(u); men_dst.append(v)

        ruid = row.get("tweets_in_reply_to_user_id", None)
        if pd.notna(ruid):
            v = uid_to_user_index.get(str(ruid))
            if v is not None:
                rep_src.append(u); rep_dst.append(v)

    src = men_src + rep_src
    dst = men_dst + rep_dst
    if len(src) == 0:
        edge_index = torch.empty((2, 0), dtype=torch.long)
        edge_type  = torch.empty((0,), dtype=torch.long)
    else:
        edge_index = torch.tensor([src, dst], dtype=torch.long)
        edge_type  = torch.tensor([0]*len(men_src) + [1]*len(rep_src), dtype=torch.long)

    labels = user_tbl["label"].apply(_label_to_int).astype(int).values
    labels = torch.LongTensor(labels)

    train_uid_with_label = user_tbl[user_tbl["split"] == "train"][["user_id", "split", "label"]].rename(columns={"user_id": "id"})
    valid_uid_with_label = user_tbl[user_tbl["split"] == "val"][["user_id", "split", "label"]].rename(columns={"user_id": "id"})
    test_uid_with_label  = user_tbl[user_tbl["split"] == "test"][["user_id", "split", "label"]].rename(columns={"user_id": "id"})

    if include_node_feature:
        tok = RobertaTokenizer.from_pretrained("roberta-base")
        mdl = RobertaModel.from_pretrained("roberta-base")

        user_desc = (df[["user_id", "user_profile"]]
                     .drop_duplicates(subset=["user_id"], keep="first")
                     .set_index("user_id")
                     .reindex(user_ids)["user_profile"]
                     .fillna("").astype(str).tolist())

        feats = []
        for txt in tqdm(user_desc, desc="Embedding users"):
            if not txt:
                feats.append(torch.zeros(768))
                continue
            enc = tok(str(txt), return_tensors="pt", truncation=True, max_length=512)
            out = mdl(**enc)
            h = out.last_hidden_state.mean(dim=1).squeeze(0)
            feats.append(h.detach().cpu())
        user_text_feats = torch.stack(feats, dim=0)

        cdir = _cache_dir(dataset)
        torch.save({
            "user_text_feats": user_text_feats,
            "edge_index": edge_index,
            "edge_type": edge_type,
            "labels": labels,
            "uid_to_user_index": uid_to_user_index,
            "train_uid_with_label": train_uid_with_label,
            "valid_uid_with_label": valid_uid_with_label,
            "test_uid_with_label":  test_uid_with_label,
        }, cdir / "user_info.pt")

        return (user_text_feats, edge_index, edge_type, labels,
                uid_to_user_index, train_uid_with_label, valid_uid_with_label, test_uid_with_label)

    return (edge_index, edge_type, labels,
            uid_to_user_index,
            train_uid_with_label, valid_uid_with_label, test_uid_with_label)

def df_to_mask(uid_with_label: pd.DataFrame, uid_to_user_index: dict, phase="train"):
    user_list = list(uid_with_label[uid_with_label.split == phase].id)
    phase_index = [uid_to_user_index[x] for x in user_list if x in uid_to_user_index]
    return torch.LongTensor(phase_index)

# ----------------------------------------------------------

if __name__ == "__main__":
    # Test with Benchmark_data_10k (or a literal CSV path)
    print("Testing merge('Benchmark_data_10k') ...")
    try:
        data = merge("Benchmark_data_10k", "209")
        print(f"Data shape: {data.shape}")
        print(f"Columns: {data.columns.tolist()[:12]} ...")
    except Exception as e:
        print("Merge test failed:", e)

    # Literal CSV path test (uncomment and point to your file)
    # print("Testing merge('/path/to/Unseen_data_testing_with_split_1m.csv') ...")
    # data2 = merge("/path/to/Unseen_data_testing_with_split_1m.csv", "209")
    # print("Data2 shape:", data2.shape)
